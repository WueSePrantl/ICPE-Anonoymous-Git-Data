import argparse
import random
import string
import time
from io import StringIO
from multiprocessing import Process

import carbontracker.constants as ct

ct.PUE_2023 = 1.0


def generate_text(size_mb):
    chars = string.ascii_letters + string.digits + " "
    return "".join(random.choice(chars) for _ in range(size_mb * 1024 * 1024))


def lzw_compress(uncompressed):
    dictionary = {chr(i): i for i in range(256)}
    dict_size = 256
    w = ""
    result = []

    for c in uncompressed:
        wc = w + c
        if wc in dictionary:
            w = wc
        else:
            result.append(dictionary[w])
            dictionary[wc] = dict_size
            dict_size += 1
            w = c

    if w:
        result.append(dictionary[w])

    return result


def lzw_decompress(compressed):
    dictionary = {i: chr(i) for i in range(256)}
    dict_size = 256
    result = StringIO()

    if not compressed:
        return ""

    w = dictionary[compressed[0]]
    result.write(w)

    for k in compressed[1:]:
        if k in dictionary:
            entry = dictionary[k]
        elif k == dict_size:
            entry = w + w[0]
        else:
            raise ValueError(f"Bad compressed code: {k}")

        result.write(entry)
        dictionary[dict_size] = w + entry[0]
        dict_size += 1
        w = entry

    return result.getvalue()


def run_worklet(size_mb, do_decompress):
    data = generate_text(size_mb)
    compressed = lzw_compress(data)

    if do_decompress:
        decompressed = lzw_decompress(compressed)
        assert data == decompressed, "Decompression does not match the original data"


def worker(size_mb, repeats, do_decompress):
    for i in range(repeats):
        run_worklet(size_mb, do_decompress)
        if i % 4 == 0:
            print(f"finished repeat {i + 1} of {repeats} at time: {time.time()}")


def run_multiprocess(processes, size_mb, repeats, do_decompress):
    procs = []
    for _ in range(processes):
        process = Process(target=worker, args=(size_mb, repeats, do_decompress))
        process.start()
        procs.append(process)

    for process in procs:
        process.join()


def main():
    parser = argparse.ArgumentParser(description="SPEC SERT-inspired LZW Compress Worklet")
    parser.add_argument("--size-mb", type=int, default=5, help="Size of generated input data in MB")
    parser.add_argument("--repeat", type=int, default=1, help="Repetitions per process")
    parser.add_argument("--processes", type=int, default=1, help="Number of worker processes")
    parser.add_argument("--decompress", action="store_true", help="Also run LZW decompression")
    parser.add_argument("--measure", choices=["codecarbon", "carbontracker", "eco2ai"], help="Energy tracker")
    args = parser.parse_args()

    tracker = None
    if args.measure == "codecarbon":
        from codecarbon import OfflineEmissionsTracker

        tracker = OfflineEmissionsTracker(country_iso_code="DEU", force_ram_power=10)
        tracker.start()
    elif args.measure == "carbontracker":
        from carbontracker.tracker import CarbonTracker

        tracker = CarbonTracker(epochs=1)
        tracker.epoch_start()
    elif args.measure == "eco2ai":
        import eco2ai

        tracker = eco2ai.Tracker(
            project_name="LZW Compress CPU Worklet",
            file_name="compress_eco2ai.csv",
        )
        tracker.start()

    print("Running workload...")
    start = time.time()
    run_multiprocess(args.processes, args.size_mb, args.repeat, args.decompress)
    end = time.time()

    if args.measure == "codecarbon":
        tracker.stop()
    elif args.measure == "carbontracker":
        tracker.epoch_end()
        tracker.stop()
    elif args.measure == "eco2ai":
        tracker.stop()

    print(f"Total runtime: {end - start:.2f} seconds")


if __name__ == "__main__":
    main()
