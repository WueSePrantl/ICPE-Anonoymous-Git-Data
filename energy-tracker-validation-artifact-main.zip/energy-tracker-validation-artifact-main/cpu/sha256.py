import argparse
import hashlib
import os
import time
from multiprocessing import Process

import carbontracker.constants as ct

ct.PUE_2023 = 1.0


def generate_data(size_mb: int):
    return os.urandom(size_mb * 1024 * 1024)


def sha256_hash(data):
    return hashlib.sha256(data).digest()


def run_worklet(size_mb):
    data = generate_data(size_mb)
    sha256_hash(data)


def worker(size_mb, repeats):
    for i in range(repeats):
        run_worklet(size_mb)
        if i % 50 == 0:
            print(f"finished repeat {i + 1} of {repeats} at time: {time.time()}")


def run_multiprocess(processes, size_mb, repeats):
    procs = []
    for _ in range(processes):
        process = Process(target=worker, args=(size_mb, repeats))
        process.start()
        procs.append(process)

    for process in procs:
        process.join()


def main():
    parser = argparse.ArgumentParser(description="SPEC SERT-inspired SHA256 Worklet")
    parser.add_argument("--size-mb", type=int, default=5, help="Size of random input data in MB")
    parser.add_argument("--repeat", type=int, default=1, help="Repetitions per process")
    parser.add_argument("--processes", type=int, default=1)
    parser.add_argument("--measure", choices=["codecarbon", "carbontracker", "eco2ai"])
    args = parser.parse_args()

    tracker = None
    if args.measure == "codecarbon":
        from codecarbon import OfflineEmissionsTracker

        tracker = OfflineEmissionsTracker(country_iso_code="DEU", force_ram_power=10)
        tracker.start()
    elif args.measure == "carbontracker":
        from carbontracker.tracker import CarbonTracker

        tracker = CarbonTracker(epochs=1)
        tracker.epoch_start()
    elif args.measure == "eco2ai":
        import eco2ai

        tracker = eco2ai.Tracker(
            project_name="SHA256 CPU Worklet",
            file_name="sha256_eco2ai.csv",
        )
        tracker.start()

    print("Running workload...")
    start = time.time()
    run_multiprocess(args.processes, args.size_mb, args.repeat)
    end = time.time()

    if args.measure == "codecarbon":
        tracker.stop()
    elif args.measure == "carbontracker":
        tracker.epoch_end()
        tracker.stop()
    elif args.measure == "eco2ai":
        tracker.stop()

    print(f"Total runtime: {end - start:.2f} seconds")


if __name__ == "__main__":
    main()
