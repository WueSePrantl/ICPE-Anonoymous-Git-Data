import argparse
import time
from multiprocessing import Process

import carbontracker.constants as ct
import numpy as np

ct.PUE_2023 = 1.0


def sor_iteration(matrix, b, x, omega):
    n = len(matrix)
    for i in range(n):
        sigma = 0.0
        for j in range(n):
            if j != i:
                sigma += matrix[i, j] * x[j]
        x[i] = (1 - omega) * x[i] + (omega * (b[i] - sigma) / matrix[i, i])
    return x


def run_worklet(n, iterations, omega):
    matrix = np.random.rand(n, n)

    # Ensure diagonal dominance for the iterative solver.
    for i in range(n):
        matrix[i, i] += n

    b = np.random.rand(n)
    x = np.zeros(n)

    for _ in range(iterations):
        x = sor_iteration(matrix, b, x, omega)

    return x


def worker(n, repeats, iterations, omega):
    for i in range(repeats):
        run_worklet(n, iterations, omega)
        if i % 50 == 0:
            print(f"finished repeat {i + 1} of {repeats} at time: {time.ctime()}")


def run_multiprocess(processes, n, repeats, iterations, omega):
    procs = []
    for _ in range(processes):
        process = Process(target=worker, args=(n, repeats, iterations, omega))
        process.start()
        procs.append(process)

    for process in procs:
        process.join()


def main():
    parser = argparse.ArgumentParser(description="SPEC SERT-inspired SOR Worklet")
    parser.add_argument("--matrix-size", type=int, default=300, help="Matrix dimension n for an n x n matrix")
    parser.add_argument("--iterations", type=int, default=50, help="Number of SOR iterations")
    parser.add_argument("--omega", type=float, default=1.25, help="Relaxation factor")
    parser.add_argument("--processes", type=int, default=1)
    parser.add_argument("--repeat", type=int, default=1)
    parser.add_argument("--measure", choices=["codecarbon", "carbontracker", "eco2ai"])
    args = parser.parse_args()

    tracker = None
    if args.measure == "codecarbon":
        from codecarbon import OfflineEmissionsTracker

        tracker = OfflineEmissionsTracker(country_iso_code="DEU", force_ram_power=10)
        tracker.start()
    elif args.measure == "carbontracker":
        from carbontracker.tracker import CarbonTracker

        tracker = CarbonTracker(epochs=1)
        tracker.epoch_start()
    elif args.measure == "eco2ai":
        import eco2ai

        tracker = eco2ai.Tracker(
            project_name="SOR CPU Worklet",
            file_name="sor_eco2ai.csv",
        )
        tracker.start()

    print("Running workload...")
    start = time.time()
    run_multiprocess(
        args.processes,
        args.matrix_size,
        args.repeat,
        args.iterations,
        args.omega,
    )
    end = time.time()

    if args.measure == "codecarbon":
        tracker.stop()
    elif args.measure == "carbontracker":
        tracker.epoch_end()
        tracker.stop()
    elif args.measure == "eco2ai":
        tracker.stop()

    print(f"Total runtime: {end - start:.2f} seconds")


if __name__ == "__main__":
    main()
