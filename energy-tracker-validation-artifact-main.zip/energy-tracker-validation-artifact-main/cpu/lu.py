import argparse
import time
from multiprocessing import Process

import carbontracker.constants as ct
import numpy as np

ct.PUE_2023 = 1.0


def lu_decompose(matrix):
    n = matrix.shape[0]
    lower = np.eye(n)
    upper = np.zeros_like(matrix)

    for i in range(n):
        for j in range(i, n):
            upper[i, j] = matrix[i, j] - np.dot(lower[i, :i], upper[:i, j])

        for j in range(i + 1, n):
            if upper[i, i] == 0:
                raise ValueError("Zero pivot encountered")
            lower[j, i] = (
                matrix[j, i] - np.dot(lower[j, :i], upper[:i, i])
            ) / upper[i, i]

    return lower, upper


def run_worklet(n: int):
    matrix = np.random.rand(n, n).astype(np.float64)
    lu_decompose(matrix)
    return True


def worker(n, repeats):
    for i in range(repeats):
        run_worklet(n)
        if i % 50 == 0:
            print(f"finished repeat {i + 1} of {repeats} at time: {time.time()}")


def run_multiprocess(processes, n, repeats):
    procs = []
    for _ in range(processes):
        process = Process(target=worker, args=(n, repeats))
        process.start()
        procs.append(process)

    for process in procs:
        process.join()


def main():
    parser = argparse.ArgumentParser(description="SPEC SERT-inspired LU Decomposition Worklet")
    parser.add_argument(
        "--matrix-size",
        type=int,
        default=500,
        help="Matrix dimension n for an n x n matrix",
    )
    parser.add_argument("--repeat", type=int, default=1)
    parser.add_argument("--processes", type=int, default=1)
    parser.add_argument("--measure", choices=["codecarbon", "carbontracker", "eco2ai"])
    args = parser.parse_args()

    tracker = None
    if args.measure == "codecarbon":
        from codecarbon import OfflineEmissionsTracker

        tracker = OfflineEmissionsTracker(country_iso_code="DEU", force_ram_power=10)
        tracker.start()
    elif args.measure == "carbontracker":
        from carbontracker.tracker import CarbonTracker

        tracker = CarbonTracker(epochs=1)
        tracker.epoch_start()
    elif args.measure == "eco2ai":
        import eco2ai

        tracker = eco2ai.Tracker(
            project_name="LU CPU Worklet",
            file_name="lu_eco2ai.csv",
        )
        tracker.start()

    print("Running workload...")
    start = time.time()
    run_multiprocess(args.processes, args.matrix_size, args.repeat)
    end = time.time()

    if args.measure == "codecarbon":
        tracker.stop()
    elif args.measure == "carbontracker":
        tracker.epoch_end()
        tracker.stop()
    elif args.measure == "eco2ai":
        tracker.stop()

    print(f"Total runtime: {end - start:.2f} seconds")


if __name__ == "__main__":
    main()
