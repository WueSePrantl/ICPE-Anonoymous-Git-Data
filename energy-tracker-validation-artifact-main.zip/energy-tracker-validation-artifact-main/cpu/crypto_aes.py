import argparse
import os
import time
from multiprocessing import Process

import carbontracker.constants as ct
from Crypto.Cipher import AES
from Crypto.Random import get_random_bytes

ct.PUE_2023 = 1.0


def generate_data(size_mb: int):
    return os.urandom(size_mb * 1024 * 1024)


def pad(data):
    pad_len = 16 - (len(data) % 16)
    return data + bytes([pad_len] * pad_len)


def unpad(data):
    pad_len = data[-1]
    return data[:-pad_len]


def aes_encrypt_decrypt(data, mode="ECB", do_decrypt=False):
    key = get_random_bytes(32)

    if mode == "ECB":
        cipher = AES.new(key, AES.MODE_ECB)
    elif mode == "CBC":
        iv = get_random_bytes(16)
        cipher = AES.new(key, AES.MODE_CBC, iv)
    else:
        raise ValueError("Unsupported AES mode")

    encrypted = cipher.encrypt(pad(data))

    if not do_decrypt:
        return len(encrypted)

    if mode == "ECB":
        decipher = AES.new(key, AES.MODE_ECB)
    else:
        decipher = AES.new(key, AES.MODE_CBC, iv)

    decrypted = unpad(decipher.decrypt(encrypted))
    assert decrypted == data, "AES decryption does not match the original data"
    return len(encrypted)


def run_worklet(size_mb, mode, do_decrypt):
    data = generate_data(size_mb)
    aes_encrypt_decrypt(data, mode, do_decrypt)


def worker(size_mb, repeats, mode, do_decrypt):
    for i in range(repeats):
        run_worklet(size_mb, mode, do_decrypt)
        if i % 80 == 0:
            print(f"finished repeat {i + 1} of {repeats} at time: {time.time()}")


def run_multiprocess(processes, size_mb, repeats, mode, do_decrypt):
    procs = []
    for _ in range(processes):
        process = Process(target=worker, args=(size_mb, repeats, mode, do_decrypt))
        process.start()
        procs.append(process)

    for process in procs:
        process.join()


def main():
    parser = argparse.ArgumentParser(description="SPEC SERT-inspired AES Crypto Worklet")
    parser.add_argument("--size-mb", type=int, default=5)
    parser.add_argument("--repeat", type=int, default=1)
    parser.add_argument("--processes", type=int, default=1)
    parser.add_argument("--mode", choices=["ECB", "CBC"], default="ECB")
    parser.add_argument("--decrypt", action="store_true")
    parser.add_argument("--measure", choices=["codecarbon", "carbontracker", "eco2ai"])
    args = parser.parse_args()

    tracker = None
    if args.measure == "codecarbon":
        from codecarbon import OfflineEmissionsTracker

        tracker = OfflineEmissionsTracker(country_iso_code="DEU", force_ram_power=10)
        tracker.start()
    elif args.measure == "carbontracker":
        from carbontracker.tracker import CarbonTracker

        tracker = CarbonTracker(epochs=1)
        tracker.epoch_start()
    elif args.measure == "eco2ai":
        import eco2ai

        tracker = eco2ai.Tracker(
            project_name="CryptoAES CPU Worklet",
            file_name="crypto_aes_eco2ai.csv",
        )
        tracker.start()

    print("Running workload...")
    start = time.time()
    run_multiprocess(args.processes, args.size_mb, args.repeat, args.mode, args.decrypt)
    end = time.time()

    if args.measure == "codecarbon":
        tracker.stop()
    elif args.measure == "carbontracker":
        tracker.epoch_end()
        tracker.stop()
    elif args.measure == "eco2ai":
        tracker.stop()

    print(f"Total runtime: {end - start:.2f} seconds")


if __name__ == "__main__":
    main()
