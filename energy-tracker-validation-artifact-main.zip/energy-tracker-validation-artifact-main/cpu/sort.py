import argparse
import time
from multiprocessing import Process

import carbontracker.constants as ct
import numpy as np

ct.PUE_2023 = 1.0


def sort_workload(array_size):
    array = np.random.rand(array_size)
    array.sort()


def run_worklet(array_size):
    sort_workload(array_size)


def worker(array_size, repeats):
    for i in range(repeats):
        run_worklet(array_size)
        if i % 52 == 0:
            print(f"finished repeat {i + 1} of {repeats} at time: {time.time()}")


def run_multiprocess(processes, array_size, repeats):
    procs = []
    for _ in range(processes):
        process = Process(target=worker, args=(array_size, repeats))
        process.start()
        procs.append(process)

    for process in procs:
        process.join()


def main():
    parser = argparse.ArgumentParser(description="SPEC SERT-inspired Sort Worklet")
    parser.add_argument("--array-size", type=int, default=5_000_000, help="Number of elements to sort")
    parser.add_argument("--repeat", type=int, default=10, help="Repetitions per process")
    parser.add_argument("--processes", type=int, default=1)
    parser.add_argument("--measure", choices=["codecarbon", "carbontracker", "eco2ai"])
    args = parser.parse_args()

    tracker = None
    if args.measure == "codecarbon":
        from codecarbon import OfflineEmissionsTracker

        tracker = OfflineEmissionsTracker(country_iso_code="DEU", force_ram_power=10)
        tracker.start()
    elif args.measure == "carbontracker":
        from carbontracker.tracker import CarbonTracker

        tracker = CarbonTracker(epochs=1)
        tracker.epoch_start()
    elif args.measure == "eco2ai":
        import eco2ai

        tracker = eco2ai.Tracker(
            project_name="SORT CPU Worklet",
            file_name="sort_eco2ai.csv",
        )
        tracker.start()

    print("Running workload...")
    start = time.time()
    run_multiprocess(args.processes, args.array_size, args.repeat)
    end = time.time()

    if args.measure == "codecarbon":
        tracker.stop()
    elif args.measure == "carbontracker":
        tracker.epoch_end()
        tracker.stop()
    elif args.measure == "eco2ai":
        tracker.stop()

    print(f"Total runtime: {end - start:.2f} seconds")


if __name__ == "__main__":
    main()
