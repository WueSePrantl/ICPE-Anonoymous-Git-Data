import argparse
import time

import carbontracker.constants as ct
import torch
import torch.nn as nn
import torch.optim as optim

ct.PUE_2023 = 1.0


class MLP(nn.Module):
    def __init__(self, input_dim, hidden_dim, num_layers, output_dim):
        super().__init__()
        layers = [nn.Linear(input_dim, hidden_dim), nn.ReLU()]

        for _ in range(num_layers - 1):
            layers.append(nn.Linear(hidden_dim, hidden_dim))
            layers.append(nn.ReLU())

        layers.append(nn.Linear(hidden_dim, output_dim))
        self.net = nn.Sequential(*layers)

    def forward(self, x):
        return self.net(x)


def make_optimizer(name, params, lr):
    name = name.lower()
    if name == "adam":
        return optim.Adam(params, lr=lr)
    if name == "adamw":
        return optim.AdamW(params, lr=lr)
    if name == "sgd":
        return optim.SGD(params, lr=lr)
    raise ValueError(f"Unknown optimizer: {name}")


def make_loss(name):
    name = name.lower()
    if name == "mse":
        return nn.MSELoss()
    if name == "crossentropy":
        return nn.CrossEntropyLoss()
    raise ValueError(f"Unknown loss: {name}")


def run_worklet(
    input_dim,
    hidden_dim,
    output_dim,
    num_layers,
    batch_size,
    epochs,
    steps_per_epoch,
    learning_rate,
    optimizer_name,
    loss_name,
    device,
    dtype,
    seed,
    tracker=None,
    measure_name=None,
):
    torch.manual_seed(seed)

    if device == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("CUDA requested but not available")

    dev = torch.device(device)
    dt = torch.float16 if dtype == "fp16" else torch.float32

    model = MLP(
        input_dim=input_dim,
        hidden_dim=hidden_dim,
        num_layers=num_layers,
        output_dim=output_dim,
    ).to(dev).to(dt)

    optimizer = make_optimizer(optimizer_name, model.parameters(), learning_rate)
    loss_fn = make_loss(loss_name)

    x = torch.randn(batch_size, input_dim, device=dev, dtype=dt)
    if loss_name == "crossentropy":
        target = torch.randint(0, output_dim, (batch_size,), device=dev)
    else:
        target = torch.randn(batch_size, output_dim, device=dev, dtype=dt)

    start = time.perf_counter()

    for epoch in range(epochs):
        if measure_name == "carbontracker" and tracker:
            tracker.epoch_start()

        for _ in range(steps_per_epoch):
            optimizer.zero_grad(set_to_none=True)
            out = model(x)
            loss = loss_fn(out, target)
            loss.backward()
            optimizer.step()

        if measure_name == "carbontracker" and tracker:
            tracker.epoch_end()

        if device == "cuda":
            torch.cuda.synchronize()

        print(f"Epoch {epoch + 1}/{epochs} finished.")

    end = time.perf_counter()

    return {
        "runtime_sec": end - start,
        "epochs": epochs,
        "batch_size": batch_size,
        "input_dim": input_dim,
        "hidden_dim": hidden_dim,
        "output_dim": output_dim,
        "num_layers": num_layers,
        "optimizer": optimizer_name,
        "loss": loss_name,
        "device": device,
        "dtype": dtype,
        "seed": seed,
    }


def main():
    parser = argparse.ArgumentParser(description="GPU MLP Worklet")
    parser.add_argument("--input-dim", type=int, default=1024)
    parser.add_argument("--hidden-dim", type=int, default=2048)
    parser.add_argument("--output-dim", type=int, default=512)
    parser.add_argument("--layers", type=int, default=8)
    parser.add_argument("--batch-size", type=int, default=512)
    parser.add_argument("--epochs", type=int, default=50)
    parser.add_argument(
        "--steps-per-epoch",
        "--steps_per_epoch",
        dest="steps_per_epoch",
        type=int,
        default=20,
    )
    parser.add_argument("--optimizer", choices=["adam", "adamw", "sgd"], default="adam")
    parser.add_argument("--loss", choices=["mse", "crossentropy"], default="mse")
    parser.add_argument("--lr", type=float, default=1e-3)
    parser.add_argument("--device", choices=["cpu", "cuda"], default="cuda")
    parser.add_argument("--dtype", choices=["fp32", "fp16"], default="fp32")
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--measure", choices=["codecarbon", "carbontracker", "eco2ai"])
    args = parser.parse_args()

    tracker = None
    if args.measure == "codecarbon":
        from codecarbon import OfflineEmissionsTracker

        tracker = OfflineEmissionsTracker(country_iso_code="DEU", force_ram_power=10)
        tracker.start()
    elif args.measure == "carbontracker":
        from carbontracker.tracker import CarbonTracker

        tracker = CarbonTracker(epochs=args.epochs)
    elif args.measure == "eco2ai":
        import eco2ai

        tracker = eco2ai.Tracker(
            project_name="MLP GPU Worklet",
            file_name="mlp_eco2ai.csv",
        )
        tracker.start()

    print(f"Running workload with {args.measure} tracker...")
    start = time.time()
    stats = run_worklet(
        input_dim=args.input_dim,
        hidden_dim=args.hidden_dim,
        output_dim=args.output_dim,
        num_layers=args.layers,
        batch_size=args.batch_size,
        epochs=args.epochs,
        steps_per_epoch=args.steps_per_epoch,
        learning_rate=args.lr,
        optimizer_name=args.optimizer,
        loss_name=args.loss,
        device=args.device,
        dtype=args.dtype,
        seed=args.seed,
        tracker=tracker,
        measure_name=args.measure,
    )
    end = time.time()

    if args.measure == "codecarbon":
        tracker.stop()
    elif args.measure == "carbontracker":
        tracker.stop()
    elif args.measure == "eco2ai":
        tracker.stop()

    print(f"Total runtime: {end - start:.2f} seconds")
    print("\nMLP GPU Worklet finished:")
    for key, value in stats.items():
        print(f"{key:>15}: {value}")


if __name__ == "__main__":
    main()
