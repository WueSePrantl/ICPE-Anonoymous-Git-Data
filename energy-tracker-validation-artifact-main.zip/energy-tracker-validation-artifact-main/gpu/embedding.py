import argparse
import time

import carbontracker.constants as ct
import torch
import torch.nn as nn
import torch.optim as optim

ct.PUE_2023 = 1.0


class EmbeddingWorklet(nn.Module):
    def __init__(self, vocab_size, embed_dim, num_classes):
        super().__init__()
        self.embeddings = nn.Embedding(vocab_size, embed_dim)
        self.fc = nn.Linear(embed_dim, num_classes)

    def forward(self, x):
        embedded = self.embeddings(x)
        pooled = embedded.mean(dim=1)
        return self.fc(pooled)


def make_optimizer(name, params, lr):
    name = name.lower()
    if name == "adam":
        return optim.Adam(params, lr=lr)
    if name == "adamw":
        return optim.AdamW(params, lr=lr)
    if name == "sgd":
        return optim.SGD(params, lr=lr)
    raise ValueError(f"Unknown optimizer: {name}")


def make_loss(name):
    name = name.lower()
    if name == "mse":
        return nn.MSELoss()
    if name == "crossentropy":
        return nn.CrossEntropyLoss()
    raise ValueError(f"Unknown loss: {name}")


def run_worklet(args, tracker=None):
    torch.manual_seed(args.seed)
    dev = torch.device(args.device)
    dt = torch.float16 if args.dtype == "fp16" else torch.float32

    model = EmbeddingWorklet(args.vocab_size, args.embed_dim, args.classes).to(dev).to(dt)
    optimizer = make_optimizer(args.optimizer, model.parameters(), args.lr)
    loss_fn = make_loss(args.loss)

    x = torch.randint(
        0,
        args.vocab_size,
        (args.batch_size, args.seq_len),
        device=dev,
    )
    if args.loss == "crossentropy":
        target = torch.randint(0, args.classes, (args.batch_size,), device=dev)
    else:
        target = torch.randn(args.batch_size, args.classes, device=dev, dtype=dt)

    print(f"Starting {args.epochs} epochs with {args.steps_per_epoch} steps each...")
    start = time.perf_counter()

    for epoch in range(args.epochs):
        if args.measure == "carbontracker" and tracker:
            tracker.epoch_start()

        for _ in range(args.steps_per_epoch):
            optimizer.zero_grad(set_to_none=True)
            out = model(x)
            loss = loss_fn(out, target)
            loss.backward()
            optimizer.step()

        if args.measure == "carbontracker" and tracker:
            tracker.epoch_end()

        if args.device == "cuda":
            torch.cuda.synchronize()

        print(f"Epoch {epoch + 1}/{args.epochs} finished.")

    return time.perf_counter() - start


def main():
    parser = argparse.ArgumentParser(description="GPU Embedding Worklet")
    parser.add_argument("--vocab-size", type=int, default=250000)
    parser.add_argument("--embed-dim", type=int, default=1024)
    parser.add_argument("--seq-len", type=int, default=512)
    parser.add_argument("--classes", type=int, default=10)
    parser.add_argument("--batch-size", type=int, default=128)
    parser.add_argument("--epochs", type=int, default=10)
    parser.add_argument("--steps-per-epoch", type=int, default=100)
    parser.add_argument("--lr", type=float, default=1e-3)
    parser.add_argument("--optimizer", choices=["adam", "adamw", "sgd"], default="adam")
    parser.add_argument("--loss", choices=["mse", "crossentropy"], default="crossentropy")
    parser.add_argument("--device", default="cuda")
    parser.add_argument("--dtype", default="fp32")
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--measure", choices=["codecarbon", "carbontracker", "eco2ai"])
    args = parser.parse_args()

    tracker = None
    if args.measure == "codecarbon":
        from codecarbon import OfflineEmissionsTracker

        tracker = OfflineEmissionsTracker(country_iso_code="DEU", force_ram_power=10)
        tracker.start()
    elif args.measure == "carbontracker":
        from carbontracker.tracker import CarbonTracker

        tracker = CarbonTracker(epochs=args.epochs)
    elif args.measure == "eco2ai":
        import eco2ai

        tracker = eco2ai.Tracker(
            project_name="Embedding GPU Worklet",
            file_name="embedding_eco2ai.csv",
        )
        tracker.start()

    runtime = run_worklet(args, tracker)

    if args.measure == "codecarbon":
        tracker.stop()
    elif args.measure == "carbontracker":
        tracker.stop()
    elif args.measure == "eco2ai":
        tracker.stop()

    print(f"Total runtime: {runtime:.2f} seconds")


if __name__ == "__main__":
    main()
