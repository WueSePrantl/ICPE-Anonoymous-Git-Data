import argparse
import time

import carbontracker.constants as ct
import torch
import torch.nn as nn
import torch.optim as optim

ct.PUE_2023 = 1.0


class TransformerEncoderWorklet(nn.Module):
    def __init__(self, vocab_size, embed_dim, num_heads, num_layers, ff_dim, max_seq_len):
        super().__init__()
        self.embedding = nn.Embedding(vocab_size, embed_dim)
        encoder_layer = nn.TransformerEncoderLayer(
            d_model=embed_dim,
            nhead=num_heads,
            dim_feedforward=ff_dim,
            batch_first=True,
        )
        self.transformer = nn.TransformerEncoder(encoder_layer, num_layers=num_layers)
        self.classifier = nn.Linear(embed_dim, vocab_size)

    def forward(self, x):
        x = self.embedding(x)
        x = self.transformer(x)
        return self.classifier(x[:, -1, :])


def make_optimizer(name, params, lr):
    name = name.lower()
    if name == "adam":
        return optim.Adam(params, lr=lr)
    if name == "adamw":
        return optim.AdamW(params, lr=lr)
    if name == "sgd":
        return optim.SGD(params, lr=lr)
    raise ValueError(f"Unknown optimizer: {name}")


def make_loss(name):
    name = name.lower()
    if name == "mse":
        return nn.MSELoss()
    if name == "crossentropy":
        return nn.CrossEntropyLoss()
    raise ValueError(f"Unknown loss: {name}")


def run_worklet(args, tracker=None):
    torch.manual_seed(args.seed)
    dev = torch.device(args.device)
    dt = torch.float16 if args.dtype == "fp16" else torch.float32

    model = TransformerEncoderWorklet(
        vocab_size=args.vocab_size,
        embed_dim=args.embed_dim,
        num_heads=args.num_heads,
        num_layers=args.num_layers,
        ff_dim=args.ff_dim,
        max_seq_len=args.seq_len,
    ).to(dev).to(dt)

    optimizer = make_optimizer(args.optimizer, model.parameters(), args.lr)
    loss_fn = make_loss(args.loss)

    x = torch.randint(0, args.vocab_size, (args.batch_size, args.seq_len), device=dev)
    if args.loss == "crossentropy":
        target = torch.randint(0, args.vocab_size, (args.batch_size,), device=dev)
    else:
        target = torch.randn(args.batch_size, args.vocab_size, device=dev, dtype=dt)

    print(f"Starting {args.epochs} epochs with {args.steps_per_epoch} steps each...")
    start = time.perf_counter()

    for epoch in range(args.epochs):
        if args.measure == "carbontracker" and tracker:
            tracker.epoch_start()

        for _ in range(args.steps_per_epoch):
            optimizer.zero_grad(set_to_none=True)
            out = model(x)
            loss = loss_fn(out, target)
            loss.backward()
            optimizer.step()

        if args.measure == "carbontracker" and tracker:
            tracker.epoch_end()

        if args.device == "cuda":
            torch.cuda.synchronize()

        print(f"Epoch {epoch + 1}/{args.epochs} finished.")

    return time.perf_counter() - start


def main():
    parser = argparse.ArgumentParser(description="GPU Transformer Encoder Worklet")
    parser.add_argument("--embed-dim", type=int, default=512, help="Must be divisible by num-heads")
    parser.add_argument("--num-heads", type=int, default=8)
    parser.add_argument("--num-layers", type=int, default=6)
    parser.add_argument("--ff-dim", type=int, default=2048)
    parser.add_argument("--seq-len", type=int, default=128)
    parser.add_argument("--vocab-size", type=int, default=1000)
    parser.add_argument("--batch-size", type=int, default=64)
    parser.add_argument("--epochs", type=int, default=10)
    parser.add_argument("--steps-per-epoch", type=int, default=100)
    parser.add_argument("--lr", type=float, default=1e-3)
    parser.add_argument("--optimizer", default="adam")
    parser.add_argument("--loss", choices=["mse", "crossentropy"], default="crossentropy")
    parser.add_argument("--device", default="cuda")
    parser.add_argument("--dtype", default="fp32")
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--measure", choices=["codecarbon", "carbontracker", "eco2ai"])
    args = parser.parse_args()

    if args.embed_dim % args.num_heads != 0:
        raise ValueError("embed-dim must be divisible by num-heads")

    tracker = None
    if args.measure == "codecarbon":
        from codecarbon import OfflineEmissionsTracker

        tracker = OfflineEmissionsTracker(country_iso_code="DEU", force_ram_power=10)
        tracker.start()
    elif args.measure == "carbontracker":
        from carbontracker.tracker import CarbonTracker

        tracker = CarbonTracker(epochs=args.epochs)
    elif args.measure == "eco2ai":
        import eco2ai

        tracker = eco2ai.Tracker(
            project_name="Transformer Encoder GPU Worklet",
            file_name="transformer_encoder_eco2ai.csv",
        )
        tracker.start()

    runtime = run_worklet(args, tracker)

    if args.measure == "codecarbon":
        tracker.stop()
    elif args.measure == "carbontracker":
        tracker.stop()
    elif args.measure == "eco2ai":
        tracker.stop()

    print(f"Total runtime: {runtime:.2f} seconds")


if __name__ == "__main__":
    main()
