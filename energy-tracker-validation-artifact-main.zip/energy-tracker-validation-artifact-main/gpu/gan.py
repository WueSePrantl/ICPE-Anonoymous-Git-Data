import argparse
import time

import carbontracker.constants as ct
import torch
import torch.nn as nn
import torch.optim as optim

ct.PUE_2023 = 1.0


class Generator(nn.Module):
    def __init__(self, latent_dim, image_shape):
        super().__init__()
        self.model = nn.Sequential(
            nn.Linear(latent_dim, 256),
            nn.LeakyReLU(0.2),
            nn.Linear(256, 512),
            nn.LeakyReLU(0.2),
            nn.Linear(512, 1024),
            nn.LeakyReLU(0.2),
            nn.Linear(1024, int(torch.prod(torch.tensor(image_shape)))),
            nn.Tanh(),
        )

    def forward(self, z):
        return self.model(z)


class Discriminator(nn.Module):
    def __init__(self, image_shape):
        super().__init__()
        self.model = nn.Sequential(
            nn.Linear(int(torch.prod(torch.tensor(image_shape))), 512),
            nn.LeakyReLU(0.2),
            nn.Linear(512, 256),
            nn.LeakyReLU(0.2),
            nn.Linear(256, 1),
            nn.Sigmoid(),
        )

    def forward(self, image):
        return self.model(image.view(image.size(0), -1))


def make_optimizer(name, params, lr):
    name = name.lower()
    if name == "adam":
        return optim.Adam(params, lr=lr)
    if name == "adamw":
        return optim.AdamW(params, lr=lr)
    if name == "sgd":
        return optim.SGD(params, lr=lr)
    raise ValueError(f"Unknown optimizer: {name}")


def make_loss(name):
    name = name.lower()
    if name == "mse":
        return nn.MSELoss()
    if name == "crossentropy":
        return nn.BCELoss()
    raise ValueError(f"Unknown loss: {name}")


def run_worklet(args, tracker=None):
    torch.manual_seed(args.seed)
    dev = torch.device(args.device)
    dt = torch.float16 if args.dtype == "fp16" else torch.float32

    image_shape = (3, 64, 64)
    latent_dim = 100

    generator = Generator(latent_dim, image_shape).to(dev).to(dt)
    discriminator = Discriminator(image_shape).to(dev).to(dt)

    optimizer_generator = make_optimizer(args.optimizer, generator.parameters(), args.lr)
    optimizer_discriminator = make_optimizer(args.optimizer, discriminator.parameters(), args.lr)
    loss_fn = make_loss(args.loss)

    real_images = torch.randn(args.batch_size, *image_shape, device=dev, dtype=dt)
    valid = torch.ones(args.batch_size, 1, device=dev, dtype=dt)
    fake = torch.zeros(args.batch_size, 1, device=dev, dtype=dt)

    print(f"Starting {args.epochs} epochs with {args.steps_per_epoch} steps each...")
    start = time.perf_counter()

    for epoch in range(args.epochs):
        if args.measure == "carbontracker" and tracker:
            tracker.epoch_start()

        for _ in range(args.steps_per_epoch):
            optimizer_generator.zero_grad(set_to_none=True)
            z = torch.randn(args.batch_size, latent_dim, device=dev, dtype=dt)
            generated_images = generator(z)
            generator_loss = loss_fn(discriminator(generated_images), valid)
            generator_loss.backward()
            optimizer_generator.step()

            optimizer_discriminator.zero_grad(set_to_none=True)
            real_loss = loss_fn(discriminator(real_images), valid)
            fake_loss = loss_fn(discriminator(generated_images.detach()), fake)
            discriminator_loss = (real_loss + fake_loss) / 2
            discriminator_loss.backward()
            optimizer_discriminator.step()

        if args.measure == "carbontracker" and tracker:
            tracker.epoch_end()

        if args.device == "cuda":
            torch.cuda.synchronize()

        print(f"Epoch {epoch + 1}/{args.epochs} finished.")

    return time.perf_counter() - start


def main():
    parser = argparse.ArgumentParser(description="GPU GAN Worklet")
    parser.add_argument("--batch-size", type=int, default=128)
    parser.add_argument("--epochs", type=int, default=10)
    parser.add_argument("--steps-per-epoch", type=int, default=100)
    parser.add_argument("--lr", type=float, default=0.0002)
    parser.add_argument("--optimizer", choices=["adam", "adamw", "sgd"], default="adam")
    parser.add_argument("--loss", choices=["mse", "crossentropy"], default="crossentropy")
    parser.add_argument("--device", default="cuda")
    parser.add_argument("--dtype", default="fp32")
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--measure", choices=["codecarbon", "carbontracker", "eco2ai"])
    args = parser.parse_args()

    tracker = None
    if args.measure == "codecarbon":
        from codecarbon import OfflineEmissionsTracker

        tracker = OfflineEmissionsTracker(country_iso_code="DEU", force_ram_power=10)
        tracker.start()
    elif args.measure == "carbontracker":
        from carbontracker.tracker import CarbonTracker

        tracker = CarbonTracker(epochs=args.epochs)
    elif args.measure == "eco2ai":
        import eco2ai

        tracker = eco2ai.Tracker(
            project_name="GAN GPU Worklet",
            file_name="gan_eco2ai.csv",
        )
        tracker.start()

    runtime = run_worklet(args, tracker)

    if args.measure == "codecarbon":
        tracker.stop()
    elif args.measure == "carbontracker":
        tracker.stop()
    elif args.measure == "eco2ai":
        tracker.stop()

    print(f"Total runtime: {runtime:.2f} seconds")


if __name__ == "__main__":
    main()
