import argparse
import time

import carbontracker.constants as ct
import torch
import torch.nn as nn
import torch.optim as optim

ct.PUE_2023 = 1.0


class CNN(nn.Module):
    def __init__(self, in_channels, num_classes, filters):
        super().__init__()
        layers = []
        channels = in_channels

        for filters_out in filters:
            layers.append(nn.Conv2d(channels, filters_out, kernel_size=3, padding=1))
            layers.append(nn.ReLU())
            layers.append(nn.MaxPool2d(kernel_size=2))
            channels = filters_out

        self.features = nn.Sequential(*layers)
        self.flatten = nn.Flatten()
        self.classifier = nn.Sequential(
            nn.Linear(filters[-1] * 14 * 14, 512),
            nn.ReLU(),
            nn.Linear(512, num_classes),
        )

    def forward(self, x):
        x = self.features(x)
        x = self.flatten(x)
        return self.classifier(x)


def make_optimizer(name, params, lr):
    name = name.lower()
    if name == "adam":
        return optim.Adam(params, lr=lr)
    if name == "adamw":
        return optim.AdamW(params, lr=lr)
    if name == "sgd":
        return optim.SGD(params, lr=lr)
    raise ValueError(f"Unknown optimizer: {name}")


def make_loss(name):
    name = name.lower()
    if name == "mse":
        return nn.MSELoss()
    if name == "crossentropy":
        return nn.CrossEntropyLoss()
    raise ValueError(f"Unknown loss: {name}")


def run_worklet(args, tracker=None):
    torch.manual_seed(args.seed)
    dev = torch.device(args.device)
    dt = torch.float16 if args.dtype == "fp16" else torch.float32

    filters = [64, 128, 256, 512]
    model = CNN(3, args.classes, filters).to(dev).to(dt)
    optimizer = make_optimizer(args.optimizer, model.parameters(), args.lr)
    loss_fn = make_loss(args.loss)

    x = torch.randn(args.batch_size, 3, 224, 224, device=dev, dtype=dt)
    target = torch.randint(0, args.classes, (args.batch_size,), device=dev)

    if args.loss == "crossentropy":
        target = torch.randint(0, args.classes, (args.batch_size,), device=dev)
    else:
        target = torch.randn(args.batch_size, args.classes, device=dev, dtype=dt)

    print(f"Starting {args.epochs} epochs with {args.steps_per_epoch} steps each...")
    start = time.perf_counter()

    for epoch in range(args.epochs):
        if args.measure == "carbontracker" and tracker:
            tracker.epoch_start()

        for _ in range(args.steps_per_epoch):
            optimizer.zero_grad(set_to_none=True)
            out = model(x)
            loss = loss_fn(out, target)
            loss.backward()
            optimizer.step()

        if args.measure == "carbontracker" and tracker:
            tracker.epoch_end()

        if args.device == "cuda":
            torch.cuda.synchronize()

        print(f"Epoch {epoch + 1}/{args.epochs} finished.")

    return time.perf_counter() - start


def main():
    parser = argparse.ArgumentParser(description="GPU CNN Worklet")
    parser.add_argument("--batch-size", type=int, default=64)
    parser.add_argument("--epochs", type=int, default=10)
    parser.add_argument("--steps-per-epoch", type=int, default=100)
    parser.add_argument("--classes", type=int, default=1000)
    parser.add_argument("--lr", type=float, default=1e-3)
    parser.add_argument("--optimizer", default="adam")
    parser.add_argument("--device", default="cuda")
    parser.add_argument("--dtype", default="fp32")
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--loss", choices=["mse", "crossentropy"], default="mse")
    parser.add_argument("--measure", choices=["codecarbon", "carbontracker", "eco2ai"])
    args = parser.parse_args()

    tracker = None
    if args.measure == "codecarbon":
        from codecarbon import OfflineEmissionsTracker

        tracker = OfflineEmissionsTracker(country_iso_code="DEU", force_ram_power=10)
        tracker.start()
    elif args.measure == "carbontracker":
        from carbontracker.tracker import CarbonTracker

        tracker = CarbonTracker(epochs=args.epochs)
    elif args.measure == "eco2ai":
        import eco2ai

        tracker = eco2ai.Tracker(
            project_name="CNN GPU Worklet",
            file_name="cnn_eco2ai.csv",
        )
        tracker.start()

    runtime = run_worklet(args, tracker)

    if args.measure == "codecarbon":
        tracker.stop()
    elif args.measure == "carbontracker":
        tracker.stop()
    elif args.measure == "eco2ai":
        tracker.stop()

    print(f"Total runtime: {runtime:.2f} seconds")


if __name__ == "__main__":
    main()
