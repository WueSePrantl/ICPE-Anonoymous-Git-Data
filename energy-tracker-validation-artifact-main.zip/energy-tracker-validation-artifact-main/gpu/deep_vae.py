import argparse
import time

import carbontracker.constants as ct
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim

ct.PUE_2023 = 1.0


class DeepVAE(nn.Module):
    def __init__(self, input_dim, hidden_dim, latent_dim, num_layers):
        super().__init__()

        encoder_layers = [nn.Linear(input_dim, hidden_dim), nn.ReLU()]
        for _ in range(num_layers - 1):
            encoder_layers.append(nn.Linear(hidden_dim, hidden_dim))
            encoder_layers.append(nn.ReLU())
        self.encoder_backbone = nn.Sequential(*encoder_layers)

        self.fc_mu = nn.Linear(hidden_dim, latent_dim)
        self.fc_logvar = nn.Linear(hidden_dim, latent_dim)

        decoder_layers = [nn.Linear(latent_dim, hidden_dim), nn.ReLU()]
        for _ in range(num_layers - 1):
            decoder_layers.append(nn.Linear(hidden_dim, hidden_dim))
            decoder_layers.append(nn.ReLU())
        self.decoder_backbone = nn.Sequential(*decoder_layers)
        self.fc_final = nn.Linear(hidden_dim, input_dim)

    def encode(self, x):
        hidden = self.encoder_backbone(x)
        return self.fc_mu(hidden), self.fc_logvar(hidden)

    def reparameterize(self, mu, logvar):
        std = torch.exp(0.5 * logvar)
        eps = torch.randn_like(std)
        return mu + eps * std

    def decode(self, z):
        hidden = self.decoder_backbone(z)
        return torch.sigmoid(self.fc_final(hidden))

    def forward(self, x):
        mu, logvar = self.encode(x.view(-1, x.shape[-1]))
        z = self.reparameterize(mu, logvar)
        return self.decode(z), mu, logvar


def make_optimizer(name, params, lr):
    name = name.lower()
    if name == "adam":
        return optim.Adam(params, lr=lr)
    if name == "adamw":
        return optim.AdamW(params, lr=lr)
    if name == "sgd":
        return optim.SGD(params, lr=lr)
    raise ValueError(f"Unknown optimizer: {name}")


def vae_loss_function(reconstructed, x, mu, logvar, loss_type="crossentropy"):
    if loss_type == "mse":
        reconstruction_loss = F.mse_loss(
            reconstructed,
            x.view(-1, x.shape[-1]),
            reduction="sum",
        )
    else:
        reconstruction_loss = F.binary_cross_entropy(
            reconstructed,
            x.view(-1, x.shape[-1]),
            reduction="sum",
        )

    kl_divergence = -0.5 * torch.sum(1 + logvar - mu.pow(2) - logvar.exp())
    return reconstruction_loss + kl_divergence


def run_worklet(args, tracker=None):
    torch.manual_seed(args.seed)
    dev = torch.device(args.device)
    dt = torch.float16 if args.dtype == "fp16" else torch.float32

    model = DeepVAE(
        args.input_dim,
        args.hidden_dim,
        args.latent_dim,
        args.layers,
    ).to(dev).to(dt)
    optimizer = make_optimizer(args.optimizer, model.parameters(), args.lr)
    x = torch.rand(args.batch_size, args.input_dim, device=dev, dtype=dt)

    print(f"Starting {args.epochs} epochs with {args.steps_per_epoch} steps each...")
    start = time.perf_counter()

    for epoch in range(args.epochs):
        if args.measure == "carbontracker" and tracker:
            tracker.epoch_start()

        for _ in range(args.steps_per_epoch):
            optimizer.zero_grad(set_to_none=True)
            reconstructed, mu, logvar = model(x)
            loss = vae_loss_function(reconstructed, x, mu, logvar, args.loss)
            loss.backward()
            optimizer.step()

        if args.measure == "carbontracker" and tracker:
            tracker.epoch_end()

        if args.device == "cuda":
            torch.cuda.synchronize()

        print(f"Epoch {epoch + 1}/{args.epochs} finished.")

    return time.perf_counter() - start


def main():
    parser = argparse.ArgumentParser(description="GPU Deep VAE Worklet")
    parser.add_argument("--input-dim", type=int, default=784)
    parser.add_argument("--hidden-dim", type=int, default=4096)
    parser.add_argument("--latent-dim", type=int, default=256)
    parser.add_argument("--layers", type=int, default=10, help="Number of layers in encoder and decoder")
    parser.add_argument("--batch-size", type=int, default=1024)
    parser.add_argument("--epochs", type=int, default=30)
    parser.add_argument("--steps-per-epoch", type=int, default=200)
    parser.add_argument("--lr", type=float, default=1e-3)
    parser.add_argument("--optimizer", choices=["adam", "adamw", "sgd"], default="adam")
    parser.add_argument("--loss", choices=["mse", "crossentropy"], default="mse")
    parser.add_argument("--device", default="cuda")
    parser.add_argument("--dtype", default="fp32")
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--measure", choices=["codecarbon", "carbontracker", "eco2ai"])
    args = parser.parse_args()

    tracker = None
    if args.measure == "codecarbon":
        from codecarbon import OfflineEmissionsTracker

        tracker = OfflineEmissionsTracker(country_iso_code="DEU", force_ram_power=10)
        tracker.start()
    elif args.measure == "carbontracker":
        from carbontracker.tracker import CarbonTracker

        tracker = CarbonTracker(epochs=args.epochs)
    elif args.measure == "eco2ai":
        from eco2ai import Tracker

        tracker = Tracker(
            project_name="Deep VAE GPU Worklet",
            file_name="deep_vae_eco2ai.csv",
        )
        tracker.start()

    runtime = run_worklet(args, tracker)

    if args.measure == "codecarbon":
        tracker.stop()
    elif args.measure == "carbontracker":
        tracker.stop()
    elif args.measure == "eco2ai":
        tracker.stop()

    print(f"Total runtime: {runtime:.2f} seconds")


if __name__ == "__main__":
    main()
