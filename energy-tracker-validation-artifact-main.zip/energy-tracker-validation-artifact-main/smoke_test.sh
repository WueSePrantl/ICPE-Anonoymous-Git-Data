#!/usr/bin/env bash
set -euo pipefail

PYTHON_BIN="${PYTHON_BIN:-python}"
RUN_GPU="${RUN_GPU:-0}"

printf 'Running CPU smoke tests...\n'
"$PYTHON_BIN" cpu/compress.py --size-mb 1 --repeat 1 --processes 1
"$PYTHON_BIN" cpu/crypto_aes.py --size-mb 1 --repeat 1 --processes 1
"$PYTHON_BIN" cpu/lu.py --matrix-size 50 --repeat 1 --processes 1
"$PYTHON_BIN" cpu/sha256.py --size-mb 1 --repeat 1 --processes 1
"$PYTHON_BIN" cpu/sor.py --matrix-size 50 --repeat 1 --processes 1 --iterations 5
"$PYTHON_BIN" cpu/sort.py --array-size 10000 --repeat 1 --processes 1

if [[ "$RUN_GPU" == "1" ]]; then
    printf 'Running GPU smoke tests...\n'
    "$PYTHON_BIN" gpu/mlp.py --epochs 1 --steps-per-epoch 1 --batch-size 8 --hidden-dim 64 --layers 2
    "$PYTHON_BIN" gpu/cnn.py --epochs 1 --steps-per-epoch 1 --batch-size 4 --classes 10
    "$PYTHON_BIN" gpu/transformer_encoder.py --epochs 1 --steps-per-epoch 1 --batch-size 4 --embed-dim 64 --num-heads 4 --num-layers 1 --ff-dim 128 --seq-len 16
    "$PYTHON_BIN" gpu/transformer_decoder.py --epochs 1 --steps-per-epoch 1 --batch-size 4 --embed-dim 64 --num-heads 4 --num-layers 1 --ff-dim 128 --seq-len 16
    "$PYTHON_BIN" gpu/gan.py --epochs 1 --steps-per-epoch 1 --batch-size 8
    "$PYTHON_BIN" gpu/deep_vae.py --epochs 1 --steps-per-epoch 1 --batch-size 8 --hidden-dim 64 --layers 2
    "$PYTHON_BIN" gpu/embedding.py --epochs 1 --steps-per-epoch 1 --batch-size 4 --embed-dim 64 --seq-len 16 --vocab-size 1000 --classes 10
else
    printf 'GPU smoke tests skipped. Run with RUN_GPU=1 ./smoke_test.sh to enable them.\n'
fi

printf 'Smoke tests finished.\n'
