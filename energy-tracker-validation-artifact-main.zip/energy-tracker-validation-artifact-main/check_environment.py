#!/usr/bin/env python3

import importlib
import platform

PACKAGES = [
    ("carbontracker", "carbontracker"),
    ("codecarbon", "codecarbon"),
    ("eco2ai", "eco2ai"),
    ("numpy", "numpy"),
    ("Crypto", "pycryptodome/Crypto"),
    ("torch", "torch"),
]

print("Python:", platform.python_version())
print("Platform:", platform.platform())
print()

for module_name, label in PACKAGES:
    try:
        module = importlib.import_module(module_name)
        version = getattr(module, "__version__", "version attribute unavailable")
        print(f"{label}: {version}")
    except Exception as exc:
        print(f"{label}: NOT AVAILABLE ({exc})")

try:
    import torch

    print()
    print("CUDA available:", torch.cuda.is_available())
    if torch.cuda.is_available():
        print("CUDA runtime reported by PyTorch:", torch.version.cuda)
        print("GPU:", torch.cuda.get_device_name(0))
except Exception:
    pass
