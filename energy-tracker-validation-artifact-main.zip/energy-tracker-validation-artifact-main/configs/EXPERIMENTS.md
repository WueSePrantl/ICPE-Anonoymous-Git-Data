# Experiment Commands

This file lists the exact workload commands used for the experiments reported in the paper. Each measured run was started with elevated privileges because access to the RAPL counters on the evaluation system required them.

All commands therefore use:

```bash
sudo $(which python) ...
```

`$(which python)` is expanded by the current shell before `sudo` is executed. This makes `sudo` run the same Python interpreter that is currently active, for example the interpreter from an activated virtual environment, instead of the root user's default Python installation.

Run the commands from the artifact root directory. Every shared configuration was executed separately with CarbonTracker, CodeCarbon, and eco2AI. The external Voltcraft Energy Check 3000 was read manually for each run.

## 1. Basic CPU experiments

### LZW Compress

#### Light

```bash
sudo $(which python) ./cpu/compress.py --size-mb 18 --repeat 30 --processes 1 --measure carbontracker
sudo $(which python) ./cpu/compress.py --size-mb 18 --repeat 30 --processes 1 --measure codecarbon
sudo $(which python) ./cpu/compress.py --size-mb 18 --repeat 30 --processes 1 --measure eco2ai
sudo $(which python) ./cpu/compress.py --size-mb 18 --repeat 30 --processes 4 --measure carbontracker
sudo $(which python) ./cpu/compress.py --size-mb 18 --repeat 30 --processes 4 --measure codecarbon
sudo $(which python) ./cpu/compress.py --size-mb 18 --repeat 30 --processes 4 --measure eco2ai
sudo $(which python) ./cpu/compress.py --size-mb 18 --repeat 30 --processes 8 --measure carbontracker
sudo $(which python) ./cpu/compress.py --size-mb 18 --repeat 30 --processes 8 --measure codecarbon
sudo $(which python) ./cpu/compress.py --size-mb 18 --repeat 30 --processes 8 --measure eco2ai
sudo $(which python) ./cpu/compress.py --size-mb 18 --repeat 30 --processes 16 --measure carbontracker
sudo $(which python) ./cpu/compress.py --size-mb 18 --repeat 30 --processes 16 --measure codecarbon
sudo $(which python) ./cpu/compress.py --size-mb 18 --repeat 30 --processes 16 --measure eco2ai
```

#### Medium

```bash
sudo $(which python) ./cpu/compress.py --size-mb 30 --repeat 30 --processes 1 --measure carbontracker
sudo $(which python) ./cpu/compress.py --size-mb 30 --repeat 30 --processes 1 --measure codecarbon
sudo $(which python) ./cpu/compress.py --size-mb 30 --repeat 30 --processes 1 --measure eco2ai
sudo $(which python) ./cpu/compress.py --size-mb 30 --repeat 30 --processes 4 --measure carbontracker
sudo $(which python) ./cpu/compress.py --size-mb 30 --repeat 30 --processes 4 --measure codecarbon
sudo $(which python) ./cpu/compress.py --size-mb 30 --repeat 30 --processes 4 --measure eco2ai
sudo $(which python) ./cpu/compress.py --size-mb 30 --repeat 30 --processes 8 --measure carbontracker
sudo $(which python) ./cpu/compress.py --size-mb 30 --repeat 30 --processes 8 --measure codecarbon
sudo $(which python) ./cpu/compress.py --size-mb 30 --repeat 30 --processes 8 --measure eco2ai
sudo $(which python) ./cpu/compress.py --size-mb 30 --repeat 30 --processes 16 --measure carbontracker
sudo $(which python) ./cpu/compress.py --size-mb 30 --repeat 30 --processes 16 --measure codecarbon
sudo $(which python) ./cpu/compress.py --size-mb 30 --repeat 30 --processes 16 --measure eco2ai
```

#### Heavy

```bash
sudo $(which python) ./cpu/compress.py --size-mb 50 --repeat 30 --processes 1 --measure carbontracker
sudo $(which python) ./cpu/compress.py --size-mb 50 --repeat 30 --processes 1 --measure codecarbon
sudo $(which python) ./cpu/compress.py --size-mb 50 --repeat 30 --processes 1 --measure eco2ai
sudo $(which python) ./cpu/compress.py --size-mb 50 --repeat 30 --processes 4 --measure carbontracker
sudo $(which python) ./cpu/compress.py --size-mb 50 --repeat 30 --processes 4 --measure codecarbon
sudo $(which python) ./cpu/compress.py --size-mb 50 --repeat 30 --processes 4 --measure eco2ai
sudo $(which python) ./cpu/compress.py --size-mb 50 --repeat 30 --processes 8 --measure carbontracker
sudo $(which python) ./cpu/compress.py --size-mb 50 --repeat 30 --processes 8 --measure codecarbon
sudo $(which python) ./cpu/compress.py --size-mb 50 --repeat 30 --processes 8 --measure eco2ai
```

### CryptoAES

#### Light

```bash
sudo $(which python) ./cpu/crypto_aes.py --size-mb 160 --repeat 500 --mode ECB --processes 1 --measure carbontracker
sudo $(which python) ./cpu/crypto_aes.py --size-mb 160 --repeat 500 --mode ECB --processes 1 --measure codecarbon
sudo $(which python) ./cpu/crypto_aes.py --size-mb 160 --repeat 500 --mode ECB --processes 1 --measure eco2ai
sudo $(which python) ./cpu/crypto_aes.py --size-mb 160 --repeat 500 --mode ECB --processes 4 --measure carbontracker
sudo $(which python) ./cpu/crypto_aes.py --size-mb 160 --repeat 500 --mode ECB --processes 4 --measure codecarbon
sudo $(which python) ./cpu/crypto_aes.py --size-mb 160 --repeat 500 --mode ECB --processes 4 --measure eco2ai
sudo $(which python) ./cpu/crypto_aes.py --size-mb 160 --repeat 500 --mode ECB --processes 8 --measure carbontracker
sudo $(which python) ./cpu/crypto_aes.py --size-mb 160 --repeat 500 --mode ECB --processes 8 --measure codecarbon
sudo $(which python) ./cpu/crypto_aes.py --size-mb 160 --repeat 500 --mode ECB --processes 8 --measure eco2ai
sudo $(which python) ./cpu/crypto_aes.py --size-mb 160 --repeat 500 --mode ECB --processes 16 --measure carbontracker
sudo $(which python) ./cpu/crypto_aes.py --size-mb 160 --repeat 500 --mode ECB --processes 16 --measure codecarbon
sudo $(which python) ./cpu/crypto_aes.py --size-mb 160 --repeat 500 --mode ECB --processes 16 --measure eco2ai
```

#### Medium

```bash
sudo $(which python) ./cpu/crypto_aes.py --size-mb 350 --repeat 500 --mode ECB --processes 1 --measure carbontracker
sudo $(which python) ./cpu/crypto_aes.py --size-mb 350 --repeat 500 --mode ECB --processes 1 --measure codecarbon
sudo $(which python) ./cpu/crypto_aes.py --size-mb 350 --repeat 500 --mode ECB --processes 1 --measure eco2ai
sudo $(which python) ./cpu/crypto_aes.py --size-mb 350 --repeat 500 --mode ECB --processes 4 --measure carbontracker
sudo $(which python) ./cpu/crypto_aes.py --size-mb 350 --repeat 500 --mode ECB --processes 4 --measure codecarbon
sudo $(which python) ./cpu/crypto_aes.py --size-mb 350 --repeat 500 --mode ECB --processes 4 --measure eco2ai
sudo $(which python) ./cpu/crypto_aes.py --size-mb 350 --repeat 500 --mode ECB --processes 8 --measure carbontracker
sudo $(which python) ./cpu/crypto_aes.py --size-mb 350 --repeat 500 --mode ECB --processes 8 --measure codecarbon
sudo $(which python) ./cpu/crypto_aes.py --size-mb 350 --repeat 500 --mode ECB --processes 8 --measure eco2ai
sudo $(which python) ./cpu/crypto_aes.py --size-mb 350 --repeat 500 --mode ECB --processes 16 --measure carbontracker
sudo $(which python) ./cpu/crypto_aes.py --size-mb 350 --repeat 500 --mode ECB --processes 16 --measure codecarbon
sudo $(which python) ./cpu/crypto_aes.py --size-mb 350 --repeat 500 --mode ECB --processes 16 --measure eco2ai
```

#### Heavy

```bash
sudo $(which python) ./cpu/crypto_aes.py --size-mb 550 --repeat 500 --mode ECB --processes 1 --measure carbontracker
sudo $(which python) ./cpu/crypto_aes.py --size-mb 550 --repeat 500 --mode ECB --processes 1 --measure codecarbon
sudo $(which python) ./cpu/crypto_aes.py --size-mb 550 --repeat 500 --mode ECB --processes 1 --measure eco2ai
sudo $(which python) ./cpu/crypto_aes.py --size-mb 550 --repeat 500 --mode ECB --processes 4 --measure carbontracker
sudo $(which python) ./cpu/crypto_aes.py --size-mb 550 --repeat 500 --mode ECB --processes 4 --measure codecarbon
sudo $(which python) ./cpu/crypto_aes.py --size-mb 550 --repeat 500 --mode ECB --processes 4 --measure eco2ai
sudo $(which python) ./cpu/crypto_aes.py --size-mb 550 --repeat 500 --mode ECB --processes 8 --measure carbontracker
sudo $(which python) ./cpu/crypto_aes.py --size-mb 550 --repeat 500 --mode ECB --processes 8 --measure codecarbon
sudo $(which python) ./cpu/crypto_aes.py --size-mb 550 --repeat 500 --mode ECB --processes 8 --measure eco2ai
```

### LU decomposition

#### Light

```bash
sudo $(which python) ./cpu/lu.py --matrix-size 600 --repeat 500 --processes 1 --measure carbontracker
sudo $(which python) ./cpu/lu.py --matrix-size 600 --repeat 500 --processes 1 --measure codecarbon
sudo $(which python) ./cpu/lu.py --matrix-size 600 --repeat 500 --processes 1 --measure eco2ai
sudo $(which python) ./cpu/lu.py --matrix-size 600 --repeat 500 --processes 4 --measure carbontracker
sudo $(which python) ./cpu/lu.py --matrix-size 600 --repeat 500 --processes 4 --measure codecarbon
sudo $(which python) ./cpu/lu.py --matrix-size 600 --repeat 500 --processes 4 --measure eco2ai
sudo $(which python) ./cpu/lu.py --matrix-size 600 --repeat 500 --processes 8 --measure carbontracker
sudo $(which python) ./cpu/lu.py --matrix-size 600 --repeat 500 --processes 8 --measure codecarbon
sudo $(which python) ./cpu/lu.py --matrix-size 600 --repeat 500 --processes 8 --measure eco2ai
sudo $(which python) ./cpu/lu.py --matrix-size 600 --repeat 500 --processes 16 --measure carbontracker
sudo $(which python) ./cpu/lu.py --matrix-size 600 --repeat 500 --processes 16 --measure codecarbon
sudo $(which python) ./cpu/lu.py --matrix-size 600 --repeat 500 --processes 16 --measure eco2ai
```

#### Medium

```bash
sudo $(which python) ./cpu/lu.py --matrix-size 800 --repeat 500 --processes 1 --measure carbontracker
sudo $(which python) ./cpu/lu.py --matrix-size 800 --repeat 500 --processes 1 --measure codecarbon
sudo $(which python) ./cpu/lu.py --matrix-size 800 --repeat 500 --processes 1 --measure eco2ai
sudo $(which python) ./cpu/lu.py --matrix-size 800 --repeat 500 --processes 4 --measure carbontracker
sudo $(which python) ./cpu/lu.py --matrix-size 800 --repeat 500 --processes 4 --measure codecarbon
sudo $(which python) ./cpu/lu.py --matrix-size 800 --repeat 500 --processes 4 --measure eco2ai
sudo $(which python) ./cpu/lu.py --matrix-size 800 --repeat 500 --processes 8 --measure carbontracker
sudo $(which python) ./cpu/lu.py --matrix-size 800 --repeat 500 --processes 8 --measure codecarbon
sudo $(which python) ./cpu/lu.py --matrix-size 800 --repeat 500 --processes 8 --measure eco2ai
sudo $(which python) ./cpu/lu.py --matrix-size 800 --repeat 500 --processes 16 --measure carbontracker
sudo $(which python) ./cpu/lu.py --matrix-size 800 --repeat 500 --processes 16 --measure codecarbon
sudo $(which python) ./cpu/lu.py --matrix-size 800 --repeat 500 --processes 16 --measure eco2ai
```

#### Heavy

```bash
sudo $(which python) ./cpu/lu.py --matrix-size 970 --repeat 500 --processes 1 --measure carbontracker
sudo $(which python) ./cpu/lu.py --matrix-size 970 --repeat 500 --processes 1 --measure codecarbon
sudo $(which python) ./cpu/lu.py --matrix-size 970 --repeat 500 --processes 1 --measure eco2ai
sudo $(which python) ./cpu/lu.py --matrix-size 970 --repeat 500 --processes 4 --measure carbontracker
sudo $(which python) ./cpu/lu.py --matrix-size 970 --repeat 500 --processes 4 --measure codecarbon
sudo $(which python) ./cpu/lu.py --matrix-size 970 --repeat 500 --processes 4 --measure eco2ai
sudo $(which python) ./cpu/lu.py --matrix-size 970 --repeat 500 --processes 8 --measure carbontracker
sudo $(which python) ./cpu/lu.py --matrix-size 970 --repeat 500 --processes 8 --measure codecarbon
sudo $(which python) ./cpu/lu.py --matrix-size 970 --repeat 500 --processes 8 --measure eco2ai
```

### SHA-256

#### Light

```bash
sudo $(which python) ./cpu/sha256.py --size-mb 150 --repeat 500 --processes 1 --measure carbontracker
sudo $(which python) ./cpu/sha256.py --size-mb 150 --repeat 500 --processes 1 --measure codecarbon
sudo $(which python) ./cpu/sha256.py --size-mb 150 --repeat 500 --processes 1 --measure eco2ai
sudo $(which python) ./cpu/sha256.py --size-mb 150 --repeat 500 --processes 4 --measure carbontracker
sudo $(which python) ./cpu/sha256.py --size-mb 150 --repeat 500 --processes 4 --measure codecarbon
sudo $(which python) ./cpu/sha256.py --size-mb 150 --repeat 500 --processes 4 --measure eco2ai
sudo $(which python) ./cpu/sha256.py --size-mb 150 --repeat 500 --processes 8 --measure carbontracker
sudo $(which python) ./cpu/sha256.py --size-mb 150 --repeat 500 --processes 8 --measure codecarbon
sudo $(which python) ./cpu/sha256.py --size-mb 150 --repeat 500 --processes 8 --measure eco2ai
sudo $(which python) ./cpu/sha256.py --size-mb 150 --repeat 500 --processes 16 --measure carbontracker
sudo $(which python) ./cpu/sha256.py --size-mb 150 --repeat 500 --processes 16 --measure codecarbon
sudo $(which python) ./cpu/sha256.py --size-mb 150 --repeat 500 --processes 16 --measure eco2ai
```

#### Medium

```bash
sudo $(which python) ./cpu/sha256.py --size-mb 300 --repeat 500 --processes 1 --measure carbontracker
sudo $(which python) ./cpu/sha256.py --size-mb 300 --repeat 500 --processes 1 --measure codecarbon
sudo $(which python) ./cpu/sha256.py --size-mb 300 --repeat 500 --processes 1 --measure eco2ai
sudo $(which python) ./cpu/sha256.py --size-mb 300 --repeat 500 --processes 4 --measure carbontracker
sudo $(which python) ./cpu/sha256.py --size-mb 300 --repeat 500 --processes 4 --measure codecarbon
sudo $(which python) ./cpu/sha256.py --size-mb 300 --repeat 500 --processes 4 --measure eco2ai
sudo $(which python) ./cpu/sha256.py --size-mb 300 --repeat 500 --processes 8 --measure carbontracker
sudo $(which python) ./cpu/sha256.py --size-mb 300 --repeat 500 --processes 8 --measure codecarbon
sudo $(which python) ./cpu/sha256.py --size-mb 300 --repeat 500 --processes 8 --measure eco2ai
sudo $(which python) ./cpu/sha256.py --size-mb 300 --repeat 500 --processes 16 --measure carbontracker
sudo $(which python) ./cpu/sha256.py --size-mb 300 --repeat 500 --processes 16 --measure codecarbon
sudo $(which python) ./cpu/sha256.py --size-mb 300 --repeat 500 --processes 16 --measure eco2ai
```

#### Heavy

```bash
sudo $(which python) ./cpu/sha256.py --size-mb 450 --repeat 500 --processes 1 --measure carbontracker
sudo $(which python) ./cpu/sha256.py --size-mb 450 --repeat 500 --processes 1 --measure codecarbon
sudo $(which python) ./cpu/sha256.py --size-mb 450 --repeat 500 --processes 1 --measure eco2ai
sudo $(which python) ./cpu/sha256.py --size-mb 450 --repeat 500 --processes 4 --measure carbontracker
sudo $(which python) ./cpu/sha256.py --size-mb 450 --repeat 500 --processes 4 --measure codecarbon
sudo $(which python) ./cpu/sha256.py --size-mb 450 --repeat 500 --processes 4 --measure eco2ai
sudo $(which python) ./cpu/sha256.py --size-mb 450 --repeat 500 --processes 8 --measure carbontracker
sudo $(which python) ./cpu/sha256.py --size-mb 450 --repeat 500 --processes 8 --measure codecarbon
sudo $(which python) ./cpu/sha256.py --size-mb 450 --repeat 500 --processes 8 --measure eco2ai
```

### SOR

#### Light

```bash
sudo $(which python) ./cpu/sor.py --matrix-size 230 --repeat 500 --iterations 50 --omega 1.25 --processes 1 --measure carbontracker
sudo $(which python) ./cpu/sor.py --matrix-size 230 --repeat 500 --iterations 50 --omega 1.25 --processes 1 --measure codecarbon
sudo $(which python) ./cpu/sor.py --matrix-size 230 --repeat 500 --iterations 50 --omega 1.25 --processes 1 --measure eco2ai
sudo $(which python) ./cpu/sor.py --matrix-size 230 --repeat 500 --iterations 50 --omega 1.25 --processes 4 --measure carbontracker
sudo $(which python) ./cpu/sor.py --matrix-size 230 --repeat 500 --iterations 50 --omega 1.25 --processes 4 --measure codecarbon
sudo $(which python) ./cpu/sor.py --matrix-size 230 --repeat 500 --iterations 50 --omega 1.25 --processes 4 --measure eco2ai
sudo $(which python) ./cpu/sor.py --matrix-size 230 --repeat 500 --iterations 50 --omega 1.25 --processes 8 --measure carbontracker
sudo $(which python) ./cpu/sor.py --matrix-size 230 --repeat 500 --iterations 50 --omega 1.25 --processes 8 --measure codecarbon
sudo $(which python) ./cpu/sor.py --matrix-size 230 --repeat 500 --iterations 50 --omega 1.25 --processes 8 --measure eco2ai
sudo $(which python) ./cpu/sor.py --matrix-size 230 --repeat 500 --iterations 50 --omega 1.25 --processes 16 --measure carbontracker
sudo $(which python) ./cpu/sor.py --matrix-size 230 --repeat 500 --iterations 50 --omega 1.25 --processes 16 --measure codecarbon
sudo $(which python) ./cpu/sor.py --matrix-size 230 --repeat 500 --iterations 50 --omega 1.25 --processes 16 --measure eco2ai
```

#### Medium

```bash
sudo $(which python) ./cpu/sor.py --matrix-size 330 --repeat 500 --iterations 50 --omega 1.25 --processes 1 --measure carbontracker
sudo $(which python) ./cpu/sor.py --matrix-size 330 --repeat 500 --iterations 50 --omega 1.25 --processes 1 --measure codecarbon
sudo $(which python) ./cpu/sor.py --matrix-size 330 --repeat 500 --iterations 50 --omega 1.25 --processes 1 --measure eco2ai
sudo $(which python) ./cpu/sor.py --matrix-size 330 --repeat 500 --iterations 50 --omega 1.25 --processes 4 --measure carbontracker
sudo $(which python) ./cpu/sor.py --matrix-size 330 --repeat 500 --iterations 50 --omega 1.25 --processes 4 --measure codecarbon
sudo $(which python) ./cpu/sor.py --matrix-size 330 --repeat 500 --iterations 50 --omega 1.25 --processes 4 --measure eco2ai
sudo $(which python) ./cpu/sor.py --matrix-size 330 --repeat 500 --iterations 50 --omega 1.25 --processes 8 --measure carbontracker
sudo $(which python) ./cpu/sor.py --matrix-size 330 --repeat 500 --iterations 50 --omega 1.25 --processes 8 --measure codecarbon
sudo $(which python) ./cpu/sor.py --matrix-size 330 --repeat 500 --iterations 50 --omega 1.25 --processes 8 --measure eco2ai
sudo $(which python) ./cpu/sor.py --matrix-size 330 --repeat 500 --iterations 50 --omega 1.25 --processes 16 --measure carbontracker
sudo $(which python) ./cpu/sor.py --matrix-size 330 --repeat 500 --iterations 50 --omega 1.25 --processes 16 --measure codecarbon
sudo $(which python) ./cpu/sor.py --matrix-size 330 --repeat 500 --iterations 50 --omega 1.25 --processes 16 --measure eco2ai
```

#### Heavy

```bash
sudo $(which python) ./cpu/sor.py --matrix-size 400 --repeat 500 --iterations 50 --omega 1.25 --processes 1 --measure carbontracker
sudo $(which python) ./cpu/sor.py --matrix-size 400 --repeat 500 --iterations 50 --omega 1.25 --processes 1 --measure codecarbon
sudo $(which python) ./cpu/sor.py --matrix-size 400 --repeat 500 --iterations 50 --omega 1.25 --processes 1 --measure eco2ai
sudo $(which python) ./cpu/sor.py --matrix-size 400 --repeat 500 --iterations 50 --omega 1.25 --processes 4 --measure carbontracker
sudo $(which python) ./cpu/sor.py --matrix-size 400 --repeat 500 --iterations 50 --omega 1.25 --processes 4 --measure codecarbon
sudo $(which python) ./cpu/sor.py --matrix-size 400 --repeat 500 --iterations 50 --omega 1.25 --processes 4 --measure eco2ai
sudo $(which python) ./cpu/sor.py --matrix-size 400 --repeat 500 --iterations 50 --omega 1.25 --processes 8 --measure carbontracker
sudo $(which python) ./cpu/sor.py --matrix-size 400 --repeat 500 --iterations 50 --omega 1.25 --processes 8 --measure codecarbon
sudo $(which python) ./cpu/sor.py --matrix-size 400 --repeat 500 --iterations 50 --omega 1.25 --processes 8 --measure eco2ai
```

### SORT

#### Light

```bash
sudo $(which python) ./cpu/sort.py --array-size 8000000 --repeat 540 --processes 1 --measure carbontracker
sudo $(which python) ./cpu/sort.py --array-size 8000000 --repeat 540 --processes 1 --measure codecarbon
sudo $(which python) ./cpu/sort.py --array-size 8000000 --repeat 540 --processes 1 --measure eco2ai
sudo $(which python) ./cpu/sort.py --array-size 8000000 --repeat 540 --processes 4 --measure carbontracker
sudo $(which python) ./cpu/sort.py --array-size 8000000 --repeat 540 --processes 4 --measure codecarbon
sudo $(which python) ./cpu/sort.py --array-size 8000000 --repeat 540 --processes 4 --measure eco2ai
sudo $(which python) ./cpu/sort.py --array-size 8000000 --repeat 540 --processes 8 --measure carbontracker
sudo $(which python) ./cpu/sort.py --array-size 8000000 --repeat 540 --processes 8 --measure codecarbon
sudo $(which python) ./cpu/sort.py --array-size 8000000 --repeat 540 --processes 8 --measure eco2ai
sudo $(which python) ./cpu/sort.py --array-size 8000000 --repeat 540 --processes 16 --measure carbontracker
sudo $(which python) ./cpu/sort.py --array-size 8000000 --repeat 540 --processes 16 --measure codecarbon
sudo $(which python) ./cpu/sort.py --array-size 8000000 --repeat 540 --processes 16 --measure eco2ai
```

#### Medium

```bash
sudo $(which python) ./cpu/sort.py --array-size 16000000 --repeat 540 --processes 1 --measure carbontracker
sudo $(which python) ./cpu/sort.py --array-size 16000000 --repeat 540 --processes 1 --measure codecarbon
sudo $(which python) ./cpu/sort.py --array-size 16000000 --repeat 540 --processes 1 --measure eco2ai
sudo $(which python) ./cpu/sort.py --array-size 16000000 --repeat 540 --processes 4 --measure carbontracker
sudo $(which python) ./cpu/sort.py --array-size 16000000 --repeat 540 --processes 4 --measure codecarbon
sudo $(which python) ./cpu/sort.py --array-size 16000000 --repeat 540 --processes 4 --measure eco2ai
sudo $(which python) ./cpu/sort.py --array-size 16000000 --repeat 540 --processes 8 --measure carbontracker
sudo $(which python) ./cpu/sort.py --array-size 16000000 --repeat 540 --processes 8 --measure codecarbon
sudo $(which python) ./cpu/sort.py --array-size 16000000 --repeat 540 --processes 8 --measure eco2ai
sudo $(which python) ./cpu/sort.py --array-size 16000000 --repeat 540 --processes 16 --measure carbontracker
sudo $(which python) ./cpu/sort.py --array-size 16000000 --repeat 540 --processes 16 --measure codecarbon
sudo $(which python) ./cpu/sort.py --array-size 16000000 --repeat 540 --processes 16 --measure eco2ai
```

#### Heavy

```bash
sudo $(which python) ./cpu/sort.py --array-size 22500000 --repeat 540 --processes 1 --measure carbontracker
sudo $(which python) ./cpu/sort.py --array-size 22500000 --repeat 540 --processes 1 --measure codecarbon
sudo $(which python) ./cpu/sort.py --array-size 22500000 --repeat 540 --processes 1 --measure eco2ai
sudo $(which python) ./cpu/sort.py --array-size 22500000 --repeat 540 --processes 4 --measure carbontracker
sudo $(which python) ./cpu/sort.py --array-size 22500000 --repeat 540 --processes 4 --measure codecarbon
sudo $(which python) ./cpu/sort.py --array-size 22500000 --repeat 540 --processes 4 --measure eco2ai
sudo $(which python) ./cpu/sort.py --array-size 22500000 --repeat 540 --processes 8 --measure carbontracker
sudo $(which python) ./cpu/sort.py --array-size 22500000 --repeat 540 --processes 8 --measure codecarbon
sudo $(which python) ./cpu/sort.py --array-size 22500000 --repeat 540 --processes 8 --measure eco2ai
sudo $(which python) ./cpu/sort.py --array-size 22500000 --repeat 540 --processes 16 --measure carbontracker
sudo $(which python) ./cpu/sort.py --array-size 22500000 --repeat 540 --processes 16 --measure codecarbon
sudo $(which python) ./cpu/sort.py --array-size 22500000 --repeat 540 --processes 16 --measure eco2ai
```

### Additional CarbonTracker-only SOR run

The paper appendix contains one additional SOR Heavy run with 16 processes for CarbonTracker. It was excluded from comparative aggregates.

```bash
sudo $(which python) ./cpu/sor.py --matrix-size 400 --repeat 500 --iterations 50 --omega 1.25 --processes 16 --measure carbontracker
```

## 2. Basic GPU experiments

All basic GPU workloads used 30 epochs and synthetic data generated on the GPU. The random seed defaults to 42.

### MLP

#### Light

```bash
sudo $(which python) ./gpu/mlp.py --epochs 30 --steps-per-epoch 195 --batch-size 1024 --hidden-dim 4096 --layers 12 --measure carbontracker
sudo $(which python) ./gpu/mlp.py --epochs 30 --steps-per-epoch 195 --batch-size 1024 --hidden-dim 4096 --layers 12 --measure codecarbon
sudo $(which python) ./gpu/mlp.py --epochs 30 --steps-per-epoch 195 --batch-size 1024 --hidden-dim 4096 --layers 12 --measure eco2ai
```

#### Medium

```bash
sudo $(which python) ./gpu/mlp.py --epochs 30 --steps-per-epoch 390 --batch-size 1024 --hidden-dim 4096 --layers 12 --measure carbontracker
sudo $(which python) ./gpu/mlp.py --epochs 30 --steps-per-epoch 390 --batch-size 1024 --hidden-dim 4096 --layers 12 --measure codecarbon
sudo $(which python) ./gpu/mlp.py --epochs 30 --steps-per-epoch 390 --batch-size 1024 --hidden-dim 4096 --layers 12 --measure eco2ai
```

#### Heavy

```bash
sudo $(which python) ./gpu/mlp.py --epochs 30 --steps-per-epoch 585 --batch-size 1024 --hidden-dim 4096 --layers 12 --measure carbontracker
sudo $(which python) ./gpu/mlp.py --epochs 30 --steps-per-epoch 585 --batch-size 1024 --hidden-dim 4096 --layers 12 --measure codecarbon
sudo $(which python) ./gpu/mlp.py --epochs 30 --steps-per-epoch 585 --batch-size 1024 --hidden-dim 4096 --layers 12 --measure eco2ai
```

### CNN

#### Light

```bash
sudo $(which python) ./gpu/cnn.py --epochs 30 --steps-per-epoch 150 --batch-size 64 --classes 1000 --lr 1e-3 --optimizer adam --loss mse --measure carbontracker
sudo $(which python) ./gpu/cnn.py --epochs 30 --steps-per-epoch 150 --batch-size 64 --classes 1000 --lr 1e-3 --optimizer adam --loss mse --measure codecarbon
sudo $(which python) ./gpu/cnn.py --epochs 30 --steps-per-epoch 150 --batch-size 64 --classes 1000 --lr 1e-3 --optimizer adam --loss mse --measure eco2ai
```

#### Medium

```bash
sudo $(which python) ./gpu/cnn.py --epochs 30 --steps-per-epoch 300 --batch-size 64 --classes 1000 --lr 1e-3 --optimizer adam --loss mse --measure carbontracker
sudo $(which python) ./gpu/cnn.py --epochs 30 --steps-per-epoch 300 --batch-size 64 --classes 1000 --lr 1e-3 --optimizer adam --loss mse --measure codecarbon
sudo $(which python) ./gpu/cnn.py --epochs 30 --steps-per-epoch 300 --batch-size 64 --classes 1000 --lr 1e-3 --optimizer adam --loss mse --measure eco2ai
```

#### Heavy

```bash
sudo $(which python) ./gpu/cnn.py --epochs 30 --steps-per-epoch 450 --batch-size 64 --classes 1000 --lr 1e-3 --optimizer adam --loss mse --measure carbontracker
sudo $(which python) ./gpu/cnn.py --epochs 30 --steps-per-epoch 450 --batch-size 64 --classes 1000 --lr 1e-3 --optimizer adam --loss mse --measure codecarbon
sudo $(which python) ./gpu/cnn.py --epochs 30 --steps-per-epoch 450 --batch-size 64 --classes 1000 --lr 1e-3 --optimizer adam --loss mse --measure eco2ai
```

### Transformer Encoder

#### Light

```bash
sudo $(which python) ./gpu/transformer_encoder.py --epochs 30 --steps-per-epoch 185 --batch-size 64 --embed-dim 512 --num-heads 8 --num-layers 6 --ff-dim 2048 --seq-len 128 --vocab-size 1000 --lr 1e-3 --optimizer adam --loss crossentropy --measure carbontracker
sudo $(which python) ./gpu/transformer_encoder.py --epochs 30 --steps-per-epoch 185 --batch-size 64 --embed-dim 512 --num-heads 8 --num-layers 6 --ff-dim 2048 --seq-len 128 --vocab-size 1000 --lr 1e-3 --optimizer adam --loss crossentropy --measure codecarbon
sudo $(which python) ./gpu/transformer_encoder.py --epochs 30 --steps-per-epoch 185 --batch-size 64 --embed-dim 512 --num-heads 8 --num-layers 6 --ff-dim 2048 --seq-len 128 --vocab-size 1000 --lr 1e-3 --optimizer adam --loss crossentropy --measure eco2ai
```

#### Medium

```bash
sudo $(which python) ./gpu/transformer_encoder.py --epochs 30 --steps-per-epoch 370 --batch-size 64 --embed-dim 512 --num-heads 8 --num-layers 6 --ff-dim 2048 --seq-len 128 --vocab-size 1000 --lr 1e-3 --optimizer adam --loss crossentropy --measure carbontracker
sudo $(which python) ./gpu/transformer_encoder.py --epochs 30 --steps-per-epoch 370 --batch-size 64 --embed-dim 512 --num-heads 8 --num-layers 6 --ff-dim 2048 --seq-len 128 --vocab-size 1000 --lr 1e-3 --optimizer adam --loss crossentropy --measure codecarbon
sudo $(which python) ./gpu/transformer_encoder.py --epochs 30 --steps-per-epoch 370 --batch-size 64 --embed-dim 512 --num-heads 8 --num-layers 6 --ff-dim 2048 --seq-len 128 --vocab-size 1000 --lr 1e-3 --optimizer adam --loss crossentropy --measure eco2ai
```

#### Heavy

```bash
sudo $(which python) ./gpu/transformer_encoder.py --epochs 30 --steps-per-epoch 555 --batch-size 64 --embed-dim 512 --num-heads 8 --num-layers 6 --ff-dim 2048 --seq-len 128 --vocab-size 1000 --lr 1e-3 --optimizer adam --loss crossentropy --measure carbontracker
sudo $(which python) ./gpu/transformer_encoder.py --epochs 30 --steps-per-epoch 555 --batch-size 64 --embed-dim 512 --num-heads 8 --num-layers 6 --ff-dim 2048 --seq-len 128 --vocab-size 1000 --lr 1e-3 --optimizer adam --loss crossentropy --measure codecarbon
sudo $(which python) ./gpu/transformer_encoder.py --epochs 30 --steps-per-epoch 555 --batch-size 64 --embed-dim 512 --num-heads 8 --num-layers 6 --ff-dim 2048 --seq-len 128 --vocab-size 1000 --lr 1e-3 --optimizer adam --loss crossentropy --measure eco2ai
```

### Transformer Decoder

#### Light

```bash
sudo $(which python) ./gpu/transformer_decoder.py --epochs 30 --steps-per-epoch 130 --batch-size 64 --embed-dim 512 --num-heads 8 --num-layers 6 --ff-dim 2048 --seq-len 128 --vocab-size 1000 --lr 1e-3 --optimizer adam --loss crossentropy --measure carbontracker
sudo $(which python) ./gpu/transformer_decoder.py --epochs 30 --steps-per-epoch 130 --batch-size 64 --embed-dim 512 --num-heads 8 --num-layers 6 --ff-dim 2048 --seq-len 128 --vocab-size 1000 --lr 1e-3 --optimizer adam --loss crossentropy --measure codecarbon
sudo $(which python) ./gpu/transformer_decoder.py --epochs 30 --steps-per-epoch 130 --batch-size 64 --embed-dim 512 --num-heads 8 --num-layers 6 --ff-dim 2048 --seq-len 128 --vocab-size 1000 --lr 1e-3 --optimizer adam --loss crossentropy --measure eco2ai
```

#### Medium

```bash
sudo $(which python) ./gpu/transformer_decoder.py --epochs 30 --steps-per-epoch 260 --batch-size 64 --embed-dim 512 --num-heads 8 --num-layers 6 --ff-dim 2048 --seq-len 128 --vocab-size 1000 --lr 1e-3 --optimizer adam --loss crossentropy --measure carbontracker
sudo $(which python) ./gpu/transformer_decoder.py --epochs 30 --steps-per-epoch 260 --batch-size 64 --embed-dim 512 --num-heads 8 --num-layers 6 --ff-dim 2048 --seq-len 128 --vocab-size 1000 --lr 1e-3 --optimizer adam --loss crossentropy --measure codecarbon
sudo $(which python) ./gpu/transformer_decoder.py --epochs 30 --steps-per-epoch 260 --batch-size 64 --embed-dim 512 --num-heads 8 --num-layers 6 --ff-dim 2048 --seq-len 128 --vocab-size 1000 --lr 1e-3 --optimizer adam --loss crossentropy --measure eco2ai
```

#### Heavy

```bash
sudo $(which python) ./gpu/transformer_decoder.py --epochs 30 --steps-per-epoch 390 --batch-size 64 --embed-dim 512 --num-heads 8 --num-layers 6 --ff-dim 2048 --seq-len 128 --vocab-size 1000 --lr 1e-3 --optimizer adam --loss crossentropy --measure carbontracker
sudo $(which python) ./gpu/transformer_decoder.py --epochs 30 --steps-per-epoch 390 --batch-size 64 --embed-dim 512 --num-heads 8 --num-layers 6 --ff-dim 2048 --seq-len 128 --vocab-size 1000 --lr 1e-3 --optimizer adam --loss crossentropy --measure codecarbon
sudo $(which python) ./gpu/transformer_decoder.py --epochs 30 --steps-per-epoch 390 --batch-size 64 --embed-dim 512 --num-heads 8 --num-layers 6 --ff-dim 2048 --seq-len 128 --vocab-size 1000 --lr 1e-3 --optimizer adam --loss crossentropy --measure eco2ai
```

### GAN

#### Light

```bash
sudo $(which python) ./gpu/gan.py --epochs 30 --steps-per-epoch 2500 --batch-size 256 --lr 0.0002 --optimizer adam --loss crossentropy --measure carbontracker
sudo $(which python) ./gpu/gan.py --epochs 30 --steps-per-epoch 2500 --batch-size 256 --lr 0.0002 --optimizer adam --loss crossentropy --measure codecarbon
sudo $(which python) ./gpu/gan.py --epochs 30 --steps-per-epoch 2500 --batch-size 256 --lr 0.0002 --optimizer adam --loss crossentropy --measure eco2ai
```

#### Medium

```bash
sudo $(which python) ./gpu/gan.py --epochs 30 --steps-per-epoch 5000 --batch-size 256 --lr 0.0002 --optimizer adam --loss crossentropy --measure carbontracker
sudo $(which python) ./gpu/gan.py --epochs 30 --steps-per-epoch 5000 --batch-size 256 --lr 0.0002 --optimizer adam --loss crossentropy --measure codecarbon
sudo $(which python) ./gpu/gan.py --epochs 30 --steps-per-epoch 5000 --batch-size 256 --lr 0.0002 --optimizer adam --loss crossentropy --measure eco2ai
```

#### Heavy

```bash
sudo $(which python) ./gpu/gan.py --epochs 30 --steps-per-epoch 7500 --batch-size 256 --lr 0.0002 --optimizer adam --loss crossentropy --measure carbontracker
sudo $(which python) ./gpu/gan.py --epochs 30 --steps-per-epoch 7500 --batch-size 256 --lr 0.0002 --optimizer adam --loss crossentropy --measure codecarbon
sudo $(which python) ./gpu/gan.py --epochs 30 --steps-per-epoch 7500 --batch-size 256 --lr 0.0002 --optimizer adam --loss crossentropy --measure eco2ai
```

### Deep VAE

#### Light

```bash
sudo $(which python) ./gpu/deep_vae.py --epochs 30 --steps-per-epoch 380 --batch-size 512 --hidden-dim 2048 --layers 15 --input-dim 784 --latent-dim 256 --lr 1e-3 --optimizer adam --loss mse --measure carbontracker
sudo $(which python) ./gpu/deep_vae.py --epochs 30 --steps-per-epoch 380 --batch-size 512 --hidden-dim 2048 --layers 15 --input-dim 784 --latent-dim 256 --lr 1e-3 --optimizer adam --loss mse --measure codecarbon
sudo $(which python) ./gpu/deep_vae.py --epochs 30 --steps-per-epoch 380 --batch-size 512 --hidden-dim 2048 --layers 15 --input-dim 784 --latent-dim 256 --lr 1e-3 --optimizer adam --loss mse --measure eco2ai
```

#### Medium

```bash
sudo $(which python) ./gpu/deep_vae.py --epochs 30 --steps-per-epoch 760 --batch-size 512 --hidden-dim 2048 --layers 15 --input-dim 784 --latent-dim 256 --lr 1e-3 --optimizer adam --loss mse --measure carbontracker
sudo $(which python) ./gpu/deep_vae.py --epochs 30 --steps-per-epoch 760 --batch-size 512 --hidden-dim 2048 --layers 15 --input-dim 784 --latent-dim 256 --lr 1e-3 --optimizer adam --loss mse --measure codecarbon
sudo $(which python) ./gpu/deep_vae.py --epochs 30 --steps-per-epoch 760 --batch-size 512 --hidden-dim 2048 --layers 15 --input-dim 784 --latent-dim 256 --lr 1e-3 --optimizer adam --loss mse --measure eco2ai
```

#### Heavy

```bash
sudo $(which python) ./gpu/deep_vae.py --epochs 30 --steps-per-epoch 1140 --batch-size 512 --hidden-dim 2048 --layers 15 --input-dim 784 --latent-dim 256 --lr 1e-3 --optimizer adam --loss mse --measure carbontracker
sudo $(which python) ./gpu/deep_vae.py --epochs 30 --steps-per-epoch 1140 --batch-size 512 --hidden-dim 2048 --layers 15 --input-dim 784 --latent-dim 256 --lr 1e-3 --optimizer adam --loss mse --measure codecarbon
sudo $(which python) ./gpu/deep_vae.py --epochs 30 --steps-per-epoch 1140 --batch-size 512 --hidden-dim 2048 --layers 15 --input-dim 784 --latent-dim 256 --lr 1e-3 --optimizer adam --loss mse --measure eco2ai
```

### Embedding

#### Light

```bash
sudo $(which python) ./gpu/embedding.py --epochs 30 --steps-per-epoch 600 --batch-size 256 --embed-dim 1024 --seq-len 512 --vocab-size 100000 --classes 10 --lr 1e-3 --optimizer adam --loss crossentropy --measure carbontracker
sudo $(which python) ./gpu/embedding.py --epochs 30 --steps-per-epoch 600 --batch-size 256 --embed-dim 1024 --seq-len 512 --vocab-size 100000 --classes 10 --lr 1e-3 --optimizer adam --loss crossentropy --measure codecarbon
sudo $(which python) ./gpu/embedding.py --epochs 30 --steps-per-epoch 600 --batch-size 256 --embed-dim 1024 --seq-len 512 --vocab-size 100000 --classes 10 --lr 1e-3 --optimizer adam --loss crossentropy --measure eco2ai
```

#### Medium

```bash
sudo $(which python) ./gpu/embedding.py --epochs 30 --steps-per-epoch 1200 --batch-size 256 --embed-dim 1024 --seq-len 512 --vocab-size 100000 --classes 10 --lr 1e-3 --optimizer adam --loss crossentropy --measure carbontracker
sudo $(which python) ./gpu/embedding.py --epochs 30 --steps-per-epoch 1200 --batch-size 256 --embed-dim 1024 --seq-len 512 --vocab-size 100000 --classes 10 --lr 1e-3 --optimizer adam --loss crossentropy --measure codecarbon
sudo $(which python) ./gpu/embedding.py --epochs 30 --steps-per-epoch 1200 --batch-size 256 --embed-dim 1024 --seq-len 512 --vocab-size 100000 --classes 10 --lr 1e-3 --optimizer adam --loss crossentropy --measure eco2ai
```

#### Heavy

```bash
sudo $(which python) ./gpu/embedding.py --epochs 30 --steps-per-epoch 1800 --batch-size 256 --embed-dim 1024 --seq-len 512 --vocab-size 100000 --classes 10 --lr 1e-3 --optimizer adam --loss crossentropy --measure carbontracker
sudo $(which python) ./gpu/embedding.py --epochs 30 --steps-per-epoch 1800 --batch-size 256 --embed-dim 1024 --seq-len 512 --vocab-size 100000 --classes 10 --lr 1e-3 --optimizer adam --loss crossentropy --measure codecarbon
sudo $(which python) ./gpu/embedding.py --epochs 30 --steps-per-epoch 1800 --batch-size 256 --embed-dim 1024 --seq-len 512 --vocab-size 100000 --classes 10 --lr 1e-3 --optimizer adam --loss crossentropy --measure eco2ai
```

## 3. Parameter-variation experiments

The baseline and changed configuration of each workload were each executed once with every tracker.

#### SOR — baseline

```bash
sudo $(which python) ./cpu/sor.py --matrix-size 330 --repeat 500 --processes 8 --iterations 50 --omega 1.25 --measure carbontracker
sudo $(which python) ./cpu/sor.py --matrix-size 330 --repeat 500 --processes 8 --iterations 50 --omega 1.25 --measure codecarbon
sudo $(which python) ./cpu/sor.py --matrix-size 330 --repeat 500 --processes 8 --iterations 50 --omega 1.25 --measure eco2ai
```

#### SOR — changed

```bash
sudo $(which python) ./cpu/sor.py --matrix-size 400 --repeat 375 --processes 4 --iterations 75 --omega 1.5 --measure carbontracker
sudo $(which python) ./cpu/sor.py --matrix-size 400 --repeat 375 --processes 4 --iterations 75 --omega 1.5 --measure codecarbon
sudo $(which python) ./cpu/sor.py --matrix-size 400 --repeat 375 --processes 4 --iterations 75 --omega 1.5 --measure eco2ai
```

#### CryptoAES — baseline

```bash
sudo $(which python) ./cpu/crypto_aes.py --size-mb 550 --repeat 500 --processes 1 --mode ECB --measure carbontracker
sudo $(which python) ./cpu/crypto_aes.py --size-mb 550 --repeat 500 --processes 1 --mode ECB --measure codecarbon
sudo $(which python) ./cpu/crypto_aes.py --size-mb 550 --repeat 500 --processes 1 --mode ECB --measure eco2ai
```

#### CryptoAES — changed

```bash
sudo $(which python) ./cpu/crypto_aes.py --size-mb 550 --repeat 500 --processes 1 --mode CBC --measure carbontracker
sudo $(which python) ./cpu/crypto_aes.py --size-mb 550 --repeat 500 --processes 1 --mode CBC --measure codecarbon
sudo $(which python) ./cpu/crypto_aes.py --size-mb 550 --repeat 500 --processes 1 --mode CBC --measure eco2ai
```

#### CNN — baseline

```bash
sudo $(which python) ./gpu/cnn.py --epochs 30 --steps-per-epoch 300 --batch-size 64 --classes 1000 --lr 1e-3 --optimizer adam --loss mse --measure carbontracker
sudo $(which python) ./gpu/cnn.py --epochs 30 --steps-per-epoch 300 --batch-size 64 --classes 1000 --lr 1e-3 --optimizer adam --loss mse --measure codecarbon
sudo $(which python) ./gpu/cnn.py --epochs 30 --steps-per-epoch 300 --batch-size 64 --classes 1000 --lr 1e-3 --optimizer adam --loss mse --measure eco2ai
```

#### CNN — changed

```bash
sudo $(which python) ./gpu/cnn.py --epochs 30 --steps-per-epoch 300 --batch-size 64 --classes 2000 --lr 1e-5 --optimizer sgd --loss crossentropy --measure carbontracker
sudo $(which python) ./gpu/cnn.py --epochs 30 --steps-per-epoch 300 --batch-size 64 --classes 2000 --lr 1e-5 --optimizer sgd --loss crossentropy --measure codecarbon
sudo $(which python) ./gpu/cnn.py --epochs 30 --steps-per-epoch 300 --batch-size 64 --classes 2000 --lr 1e-5 --optimizer sgd --loss crossentropy --measure eco2ai
```

#### Embedding — baseline

```bash
sudo $(which python) ./gpu/embedding.py --epochs 30 --steps-per-epoch 1200 --batch-size 256 --embed-dim 1024 --seq-len 512 --vocab-size 100000 --classes 10 --lr 1e-3 --optimizer adam --loss crossentropy --measure carbontracker
sudo $(which python) ./gpu/embedding.py --epochs 30 --steps-per-epoch 1200 --batch-size 256 --embed-dim 1024 --seq-len 512 --vocab-size 100000 --classes 10 --lr 1e-3 --optimizer adam --loss crossentropy --measure codecarbon
sudo $(which python) ./gpu/embedding.py --epochs 30 --steps-per-epoch 1200 --batch-size 256 --embed-dim 1024 --seq-len 512 --vocab-size 100000 --classes 10 --lr 1e-3 --optimizer adam --loss crossentropy --measure eco2ai
```

#### Embedding — changed

```bash
sudo $(which python) ./gpu/embedding.py --epochs 30 --steps-per-epoch 1200 --batch-size 512 --embed-dim 2048 --seq-len 512 --vocab-size 150000 --classes 20 --lr 1e-5 --optimizer adamw --loss crossentropy --measure carbontracker
sudo $(which python) ./gpu/embedding.py --epochs 30 --steps-per-epoch 1200 --batch-size 512 --embed-dim 2048 --seq-len 512 --vocab-size 150000 --classes 20 --lr 1e-5 --optimizer adamw --loss crossentropy --measure codecarbon
sudo $(which python) ./gpu/embedding.py --epochs 30 --steps-per-epoch 1200 --batch-size 512 --embed-dim 2048 --seq-len 512 --vocab-size 150000 --classes 20 --lr 1e-5 --optimizer adamw --loss crossentropy --measure eco2ai
```

## 4. Long-duration experiments

#### SOR — long

```bash
sudo $(which python) ./cpu/sor.py --matrix-size 1040 --repeat 500 --processes 8 --iterations 50 --omega 1.25 --measure carbontracker
sudo $(which python) ./cpu/sor.py --matrix-size 1040 --repeat 500 --processes 8 --iterations 50 --omega 1.25 --measure codecarbon
sudo $(which python) ./cpu/sor.py --matrix-size 1040 --repeat 500 --processes 8 --iterations 50 --omega 1.25 --measure eco2ai
```

#### CNN — long

```bash
sudo $(which python) ./gpu/cnn.py --epochs 30 --steps-per-epoch 1800 --batch-size 64 --classes 1000 --lr 1e-3 --optimizer adam --loss mse --measure carbontracker
sudo $(which python) ./gpu/cnn.py --epochs 30 --steps-per-epoch 1800 --batch-size 64 --classes 1000 --lr 1e-3 --optimizer adam --loss mse --measure codecarbon
sudo $(which python) ./gpu/cnn.py --epochs 30 --steps-per-epoch 1800 --batch-size 64 --classes 1000 --lr 1e-3 --optimizer adam --loss mse --measure eco2ai
```

## 5. Manual wall-plug measurement

For every command above, the software-tracker run was paired with its own wall-plug measurement using the Voltcraft Energy Check 3000. The meter was external to the Python scripts. Its accumulated energy was read manually for the same workload interval. No idle baseline was subtracted from the wall-plug value.

The commands above reproduce the workload and tracker configurations. Exact energy values are hardware-dependent and are not expected to match the paper on a different system.
