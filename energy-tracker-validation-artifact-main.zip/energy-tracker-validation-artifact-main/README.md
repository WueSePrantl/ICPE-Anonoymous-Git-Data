# ICPE Energy-Tracker Workload Artifact

This artifact contains the CPU and GPU worklets used in the paper  
**"Can Free Software Trackers Replace a Plug-In Power Meter? Validating CarbonTracker, CodeCarbon, and eco2AI Against Wall-Plug Measurements"**.

The package focuses on the workload implementations and their integration with the three evaluated software energy trackers. It does not attempt to reproduce the exact wall-plug energy values on arbitrary hardware: those values depend on the host system and were read manually from the external plug-in meter during the original experiments.

## Contents

```text
.
├── README.md
├── requirements.txt
├── check_environment.py
├── smoke_test.sh
├── cpu/
│   ├── compress.py
│   ├── crypto_aes.py
│   ├── lu.py
│   ├── sha256.py
│   ├── sor.py
│   └── sort.py
├── gpu/
│   ├── mlp.py
│   ├── cnn.py
│   ├── transformer_encoder.py
│   ├── transformer_decoder.py
│   ├── gan.py
│   ├── deep_vae.py
│   └── embedding.py
└── configs/
    └── EXPERIMENTS.md
```

The six CPU programs are Python implementations inspired by the corresponding SPEC SERT worklets. They reproduce the computational character of the workloads but are not the official SERT benchmark. The seven GPU programs are synthetic PyTorch/CUDA training workloads and generate their inputs directly on the device.

## Environment used for the paper

The measurements reported in the paper were performed on:

- Ubuntu 20.04
- Python 3.8.13
- Intel Core i7-10700 (8 physical cores, 16 logical threads)
- NVIDIA GeForce RTX 3070
- 32 GB DDR4 RAM
- CarbonTracker 2.4.3
- CodeCarbon 3.2.1
- eco2AI 0.3.12
- NumPy 1.22.3
- PyCryptodome 3.23.0
- PyTorch 1.11.0
- CUDA 11.3

The package versions are pinned in `requirements.txt`. A CUDA-enabled PyTorch installation compatible with the local NVIDIA driver is required for the GPU worklets.

## Installation

A Python virtual environment is recommended.

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
```

For GPU experiments, verify that PyTorch can access the GPU:

```bash
python - <<'PY'
import torch
print("PyTorch:", torch.__version__)
print("CUDA available:", torch.cuda.is_available())
if torch.cuda.is_available():
    print("GPU:", torch.cuda.get_device_name(0))
PY
```

On the system used for the paper, access to the RAPL counters required elevated permissions. All measured experiment commands were therefore executed with `sudo` and with the Python interpreter from the active environment, for example:

```bash
sudo $(which python) ./cpu/sha256.py --size-mb 150 --repeat 500 --processes 1 --measure codecarbon
```

## Tracker selection

Every worklet accepts the option:

```text
--measure {codecarbon,carbontracker,eco2ai}
```

Only one tracker is active in a run. This matches the experimental procedure in the paper. Omitting `--measure` runs the workload without a software energy tracker and is useful for quick functionality checks.

The tracker configuration embedded in the scripts matches the paper setup:

- CarbonTracker: PUE set to 1.0.
- CodeCarbon: `OfflineEmissionsTracker`, country `DEU`, RAM power fixed to 10 W.
- eco2AI: standard `Tracker` interface.
- GPU worklets call `torch.cuda.synchronize()` at the end of every epoch.
- CarbonTracker uses its epoch interface for the GPU workloads.

## Quick functionality check

First inspect the environment:

```bash
python check_environment.py
```

The smoke tests execute the workload code without an energy tracker and therefore do not access RAPL. They can be run without `sudo`:

```bash
./smoke_test.sh
```

To include GPU smoke tests:

```bash
RUN_GPU=1 ./smoke_test.sh
```

These smoke tests use very small configurations and do **not** reproduce paper measurements. They only verify that the workload implementations execute successfully.

To additionally test tracker integration, use the same elevated invocation as for the measured experiments, for example:

```bash
sudo $(which python) ./cpu/sha256.py --size-mb 1 --repeat 1 --processes 1 --measure codecarbon
```

## Repeating the paper workloads

The exact commands used for all basic experiments, parameter variations, and long-duration runs are listed in [`configs/EXPERIMENTS.md`](configs/EXPERIMENTS.md). The file contains every measured command explicitly, including the tracker selection, so no parameters need to be filled in by the evaluator. All measured runs use `sudo $(which python)` as described above.

The external Voltcraft Energy Check 3000 was not controlled by the Python scripts. Its accumulated energy was read manually for each run and recorded together with the library-reported energy and runtime. No idle baseline was subtracted from the wall-plug value.

## Output

All scripts print the workload runtime to the terminal. The energy trackers additionally produce their normal library-specific output:

- CarbonTracker reports its tracked energy through its normal tracker output/logging.
- CodeCarbon uses the normal `OfflineEmissionsTracker` output.
- eco2AI writes a workload-specific CSV file such as `compress_eco2ai.csv` or `cnn_eco2ai.csv` in the current working directory.

If output files from several runs should be preserved separately, run each experiment from a separate output directory or rename/copy the generated files after each run.

## Expected execution time

The paper contains 295 measured runs in total. Basic runs lasted roughly 4.3 to 43 minutes on the evaluation workstation. The two long-duration configurations ran for about two hours each. A full repetition of the complete experiment matrix therefore requires substantial machine time. The small functionality checks above are intended for artifact evaluation before attempting the full configurations.

## Measurement reproducibility

Exact energy values are hardware-dependent. A run on another CPU, GPU, operating system, driver version, or power-management configuration is not expected to reproduce the numerical values from the paper. The artifact is intended to make the workload definitions, tracker integration, and experiment configurations transparent and executable.